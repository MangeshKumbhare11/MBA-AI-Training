export type MainCategory = "Men's Fashion" | "Women's Fashion" | "Accessories";

export type Subcategory =
  | 'T-shirts'
  | 'Shirts'
  | 'Jeans'
  | 'Trousers'
  | 'Jackets'
  | 'Ethnic Wear'
  | 'Kurtis'
  | 'Dresses'
  | 'Tops'
  | 'Sarees'
  | 'Watches'
  | 'Bags'
  | 'Belts'
  | 'Fashion Accessories';

export type CollectionTag =
  | 'New Arrivals'
  | 'Trending'
  | 'Best Sellers'
  | 'Featured';

export type ProductSize = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | 'One Size';

export interface ProductColor {
  name: string;
  hex: string;
}

export interface ProductReview {
  id: string;
  userId?: string;
  userName: string;
  city?: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}

export interface Product {
  id: string;
  slug: string;
  sku: string;
  name: string;
  category: MainCategory;
  subcategory: Subcategory;
  description: string;
  fabricCare: string;
  price: number;
  originalPrice: number;
  sizes: ProductSize[];
  colors: ProductColor[];
  images: string[];
  stock: number;
  rating: number;
  reviewCount: number;
  reviews: ProductReview[];
  collections: CollectionTag[];
  createdAt: string;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  originalPrice: number;
  image: string;
  size: ProductSize;
  color: string;
  quantity: number;
  maxStock: number;
  category: MainCategory;
}

export type UserRole = 'customer' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  createdAt: string;
  defaultAddress?: ShippingAddress;
}

export interface ShippingAddress {
  fullName: string;
  phone: string;
  email: string;
  street: string;
  city: string;
  state: string;
  pinCode: string;
}

export type PaymentMethod = 'UPI' | 'CARD' | 'NETBANKING' | 'COD';

export type OrderStatus =
  | 'Placed'
  | 'Confirmed'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled';

export interface OrderItem {
  productId: string;
  name: string;
  image: string;
  size: ProductSize;
  color: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  items: OrderItem[];
  shippingAddress: ShippingAddress;
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingFee: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'Paid' | 'Pending COD';
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  status: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export interface Coupon {
  code: string;
  description: string;
  type: 'percent' | 'flat';
  value: number;
  minOrder: number;
  maxDiscount?: number;
  firstOrderOnly?: boolean;
}

export interface AdminStats {
  totalRevenue: number;
  totalOrders: number;
  averageOrderValue: number;
  totalCustomers: number;
  totalProducts: number;
  lowStockCount: number;
  revenueByCategory: { category: string; revenue: number; orders: number }[];
  ordersByStatus: { status: OrderStatus; count: number }[];
}

export interface CustomerSummary {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  createdAt: string;
  orderCount: number;
  totalSpent: number;
}

import { useCallback, useEffect, useState } from 'react';
import { AccountPage } from './components/AccountPage.tsx';
import { AdminDashboard } from './components/AdminDashboard.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { CatalogPage } from './components/CatalogPage.tsx';
import { CheckoutPage } from './components/CheckoutPage.tsx';
import { Footer } from './components/Footer.tsx';
import { type AppRoute, Header } from './components/Header.tsx';
import { Homepage } from './components/Homepage.tsx';
import {
  FirstOrderPopup,
  WhatsAppConcierge,
} from './components/MarketingWidgets.tsx';
import { ProductDetailPage } from './components/ProductDetailPage.tsx';
import { StoreProvider } from './context/StoreContext.tsx';

function routeToHash(route: AppRoute): string {
  switch (route.view) {
    case 'home':
      return '#/';
    case 'catalog': {
      const params = new URLSearchParams();
      if (route.category) params.set('cat', route.category);
      if (route.subcategory) params.set('sub', route.subcategory);
      if (route.collection) params.set('col', route.collection);
      if (route.search) params.set('q', route.search);
      const qs = params.toString();
      return qs ? `#/catalog?${qs}` : '#/catalog';
    }
    case 'product':
      return `#/product/${encodeURIComponent(route.productId)}`;
    case 'checkout':
      return '#/checkout';
    case 'account':
      return `#/account${route.tab ? `?tab=${route.tab}` : ''}`;
    case 'admin':
      return '#/admin';
  }
}

function hashToRoute(hash: string): AppRoute {
  const clean = hash.replace(/^#/, '');
  if (!clean || clean === '/') return { view: 'home' };
  const [pathPart, queryPart] = clean.split('?');
  const params = new URLSearchParams(queryPart || '');

  if (pathPart === '/catalog') {
    return {
      view: 'catalog',
      category: (params.get('cat') as AppRoute extends { view: 'catalog'; category?: infer C } ? C : never) || 'All',
      subcategory: params.get('sub') || 'All',
      collection: params.get('col') || 'All',
      search: params.get('q') || '',
    };
  }
  if (pathPart.startsWith('/product/')) {
    const id = decodeURIComponent(pathPart.slice('/product/'.length));
    return { view: 'product', productId: id };
  }
  if (pathPart === '/checkout') return { view: 'checkout' };
  if (pathPart === '/account') {
    const tab = params.get('tab') as 'orders' | 'wishlist' | 'profile' | null;
    return { view: 'account', tab: tab || 'orders' };
  }
  if (pathPart === '/admin') return { view: 'admin' };
  return { view: 'home' };
}

function AppShell() {
  const [route, setRoute] = useState<AppRoute>(() =>
    hashToRoute(window.location.hash),
  );

  const navigate = useCallback((nextRoute: AppRoute) => {
    const targetHash = routeToHash(nextRoute);
    if (window.location.hash !== targetHash) {
      window.location.hash = targetHash;
    }
    setRoute(nextRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onHashChange = () => {
      setRoute(hashToRoute(window.location.hash));
      window.scrollTo({ top: 0 });
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F9FA] text-[#111315]">
      <Header route={route} onNavigate={navigate} />

      <main className="flex-1">
        {route.view === 'home' && <Homepage onNavigate={navigate} />}

        {route.view === 'catalog' && (
          <CatalogPage
            initialCategory={route.category || 'All'}
            initialSubcategory={route.subcategory || 'All'}
            initialCollection={route.collection || 'All'}
            initialSearch={route.search || ''}
            onSelectProduct={(productId) =>
              navigate({ view: 'product', productId })
            }
          />
        )}

        {route.view === 'product' && (
          <ProductDetailPage
            productId={route.productId}
            onBack={() => navigate({ view: 'catalog', category: 'All' })}
            onSelectProduct={(productId) =>
              navigate({ view: 'product', productId })
            }
            onBuyNowCheckout={() => navigate({ view: 'checkout' })}
          />
        )}

        {route.view === 'checkout' && (
          <CheckoutPage
            onContinueShopping={() =>
              navigate({ view: 'catalog', category: 'All' })
            }
            onViewOrderHistory={() =>
              navigate({ view: 'account', tab: 'orders' })
            }
          />
        )}

        {route.view === 'account' && (
          <AccountPage
            initialTab={route.tab}
            onSelectProduct={(productId) =>
              navigate({ view: 'product', productId })
            }
            onOpenAdmin={() => navigate({ view: 'admin' })}
            onBrowseCatalog={() =>
              navigate({ view: 'catalog', category: 'All' })
            }
          />
        )}

        {route.view === 'admin' && <AdminDashboard />}
      </main>

      <Footer onNavigate={navigate} />

      <CartDrawer
        onCheckout={() => navigate({ view: 'checkout' })}
        onBrowseCatalog={() => navigate({ view: 'catalog', category: 'All' })}
      />

      <AuthModal onSuccessAdmin={() => navigate({ view: 'admin' })} />
      <WhatsAppConcierge />
      <FirstOrderPopup />
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AppShell />
    </StoreProvider>
  );
}

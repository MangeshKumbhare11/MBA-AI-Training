import type { MainCategory, Subcategory } from '../types.ts';

export function formatINR(amount: number): string {
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
}

export function discountPercent(price: number, originalPrice: number): number {
  if (!originalPrice || originalPrice <= price) return 0;
  return Math.round(((originalPrice - price) / originalPrice) * 100);
}

export const CATEGORY_TAXONOMY: Record<MainCategory, Subcategory[]> = {
  "Men's Fashion": [
    'T-shirts',
    'Shirts',
    'Jeans',
    'Trousers',
    'Jackets',
    'Ethnic Wear',
  ],
  "Women's Fashion": [
    'Kurtis',
    'Dresses',
    'Tops',
    'Sarees',
    'Jeans',
    'Ethnic Wear',
  ],
  Accessories: ['Watches', 'Bags', 'Belts', 'Fashion Accessories'],
};

export const INDIAN_STATES = [
  'Andhra Pradesh',
  'Assam',
  'Bihar',
  'Chandigarh',
  'Chhattisgarh',
  'Delhi',
  'Goa',
  'Gujarat',
  'Haryana',
  'Himachal Pradesh',
  'Jammu & Kashmir',
  'Jharkhand',
  'Karnataka',
  'Kerala',
  'Madhya Pradesh',
  'Maharashtra',
  'Odisha',
  'Punjab',
  'Rajasthan',
  'Tamil Nadu',
  'Telangana',
  'Uttar Pradesh',
  'Uttarakhand',
  'West Bengal',
];

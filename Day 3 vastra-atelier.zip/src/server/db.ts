import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import type {
  Coupon,
  Order,
  Product,
  ShippingAddress,
  UserProfile,
  UserRole,
} from '../types.ts';

export interface StoredUser extends UserProfile {
  passwordHash: string;
}

export interface StoreData {
  authSecret: string;
  users: StoredUser[];
  products: Product[];
  orders: Order[];
  coupons: Coupon[];
  wishlists: Record<string, string[]>;
  newsletterSubscribers: { email: string; subscribedAt: string }[];
}

const DATA_DIR = path.join(process.cwd(), 'data');
export const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const STORE_PATH = path.join(DATA_DIR, 'store.json');

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, key] = storedHash.split(':');
  if (!salt || !key) return false;
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  const keyBuf = Buffer.from(key, 'hex');
  const derivedBuf = Buffer.from(derived, 'hex');
  if (keyBuf.length !== derivedBuf.length) return false;
  return crypto.timingSafeEqual(keyBuf, derivedBuf);
}

function seedProducts(): Product[] {
  const now = '2026-11-15T10:00:00.000Z';
  return [
    {
      id: 'prod-kora-tee',
      slug: 'kora-heavyweight-supima-tee',
      sku: 'VA-M-TSH-001',
      name: 'Kora Heavyweight Supima Tee',
      category: "Men's Fashion",
      subcategory: 'T-shirts',
      description:
        'Knit from 260 GSM extra-long-staple Indian Supima cotton with a structured drop-shoulder silhouette and breathable enzyme-washed finish tailored for humid summers.',
      fabricCare: '100% Organic Supima Cotton · Cold gentle wash · Dry flat in shade',
      price: 1999,
      originalPrice: 2499,
      sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Obsidian Charcoal', hex: '#1E2022' },
        { name: 'Alabaster Chalk', hex: '#F3F4F6' },
        { name: 'Midnight Indigo', hex: '#1E2B48' },
      ],
      images: ['/src/assets/images/mens_oversized_tee_1795244906110.jpg'],
      stock: 42,
      rating: 4.8,
      reviewCount: 2,
      reviews: [
        {
          id: 'rev-1',
          userName: 'Rohan Malhotra',
          city: 'Mumbai',
          rating: 5,
          comment: 'Remarkable fabric weight—holds its collar structure even after five washes.',
          date: '2026-11-04',
          verified: true,
        },
        {
          id: 'rev-2',
          userName: 'Kabir Sengupta',
          city: 'Kolkata',
          rating: 5,
          comment: 'Clean boxy drape without feeling bulky. Pairs effortlessly under a blazer.',
          date: '2026-11-10',
          verified: true,
        },
      ],
      collections: ['New Arrivals', 'Best Sellers', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-alibaug-linen',
      slug: 'alibaug-mandarin-linen-shirt',
      sku: 'VA-M-SHR-002',
      name: 'Alibaug Mandarin Linen Shirt',
      category: "Men's Fashion",
      subcategory: 'Shirts',
      description:
        'Cut from pure breathable Belgian-weave linen milled in Gujarat, finished with a clean band collar, mother-of-pearl buttons, and tailored gusseted hem.',
      fabricCare: '100% Pure Linen · Hand wash cold · Steam press while damp',
      price: 3499,
      originalPrice: 4299,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Raw Ivory', hex: '#F2EFE9' },
        { name: 'Slate Mist', hex: '#64748B' },
        { name: 'Onyx Black', hex: '#111315' },
      ],
      images: ['/src/assets/images/mens_linen_shirt_1795244909118.jpg'],
      stock: 28,
      rating: 4.9,
      reviewCount: 2,
      reviews: [
        {
          id: 'rev-3',
          userName: 'Vikramaditya Rao',
          city: 'Bengaluru',
          rating: 5,
          comment: 'Wore this to a daytime garden reception in Goa. Crisp, airy, and impeccable collar roll.',
          date: '2026-11-02',
          verified: true,
        },
        {
          id: 'rev-4',
          userName: 'Siddharth Nair',
          city: 'Kochi',
          rating: 5,
          comment: 'True to size with refined tailoring around the shoulders.',
          date: '2026-11-12',
          verified: true,
        },
      ],
      collections: ['New Arrivals', 'Trending', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-selvedge-jeans',
      slug: 'indigo-selvedge-tapered-jeans',
      sku: 'VA-M-JNS-003',
      name: 'Indigo Selvedge Tapered Jeans',
      category: "Men's Fashion",
      subcategory: 'Jeans',
      description:
        '13.5 oz rope-dyed Japanese-inspired selvedge denim woven in Ahmedabad with subtle comfort stretch, antique nickel hardware, and a clean athletic taper.',
      fabricCare: '98% Cotton, 2% Elastane · Wash inside out sparingly in cold water',
      price: 4499,
      originalPrice: 5499,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Deep Raw Indigo', hex: '#1C2841' },
        { name: 'Washed Slate', hex: '#4B5563' },
      ],
      images: ['/src/assets/images/mens_denim_jacket_1795244907205.jpg'],
      stock: 35,
      rating: 4.7,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-5',
          userName: 'Arjun Deshmukh',
          city: 'Pune',
          rating: 5,
          comment: 'Zero knee bagging and the dark indigo wash looks sharp for casual Fridays.',
          date: '2026-10-28',
          verified: true,
        },
      ],
      collections: ['Best Sellers'],
      createdAt: now,
    },
    {
      id: 'prod-worli-trousers',
      slug: 'worli-pleated-wool-blend-trousers',
      sku: 'VA-M-TRS-004',
      name: 'Worli Pleated Wool-Blend Trousers',
      category: "Men's Fashion",
      subcategory: 'Trousers',
      description:
        'Single-pleated tailored trousers featuring side-tab waist adjusters, horn buttons, and an effortless straight-tapered drape crafted from lightweight tropical suiting.',
      fabricCare: '65% Polyester, 30% Viscose, 5% Merino Wool · Dry clean recommended',
      price: 3999,
      originalPrice: 4999,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Charcoal Slate', hex: '#374151' },
        { name: 'Midnight Navy', hex: '#1E293B' },
      ],
      images: ['/src/assets/images/mens_linen_shirt_1795244909118.jpg'],
      stock: 22,
      rating: 4.8,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-6',
          userName: 'Devansh Kapoor',
          city: 'New Delhi',
          rating: 5,
          comment: 'The side adjusters give a bespoke fit without needing a belt.',
          date: '2026-11-08',
          verified: true,
        },
      ],
      collections: ['Trending'],
      createdAt: now,
    },
    {
      id: 'prod-bombay-jacket',
      slug: 'bombay-raw-selvedge-trucker-jacket',
      sku: 'VA-M-JKT-005',
      name: 'Bombay Raw Selvedge Trucker Jacket',
      category: "Men's Fashion",
      subcategory: 'Jackets',
      description:
        'Structured workwear silhouette cut from heavyweight rinsed indigo denim with felled interior seams, matte metal shanks, and deep welt hand-warmer pockets.',
      fabricCare: '100% Cotton Selvedge Denim · Spot clean or cold gentle wash',
      price: 6499,
      originalPrice: 7999,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: [
        { name: 'Deep Indigo', hex: '#1B2A4A' },
        { name: 'Graphite Black', hex: '#18181B' },
      ],
      images: ['/src/assets/images/mens_denim_jacket_1795244907205.jpg'],
      stock: 18,
      rating: 4.9,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-7',
          userName: 'Pranav Joshi',
          city: 'Hyderabad',
          rating: 5,
          comment: 'Substantial denim weight with clean minimalist hardware.',
          date: '2026-11-11',
          verified: true,
        },
      ],
      collections: ['New Arrivals', 'Trending', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-nawab-nehru-set',
      slug: 'nawab-midnight-silk-nehru-jacket-set',
      sku: 'VA-M-ETH-006',
      name: 'Nawab Midnight Silk Nehru Jacket & Kurta Set',
      category: "Men's Fashion",
      subcategory: 'Ethnic Wear',
      description:
        'Signature tailored midnight-indigo Matka silk bandi layered over an alabaster cotton-silk kurta with concealed placket and fine tonal piping.',
      fabricCare: 'Outer: 100% Matka Silk · Inner Kurta: Cotton Silk · Dry clean only',
      price: 8999,
      originalPrice: 11499,
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Midnight Indigo', hex: '#1B2541' },
        { name: 'Obsidian Black', hex: '#111315' },
      ],
      images: ['/src/assets/images/mens_kurta_jacket_1795244907561.jpg'],
      stock: 15,
      rating: 5.0,
      reviewCount: 2,
      reviews: [
        {
          id: 'rev-8',
          userName: 'Aarav Sharma',
          city: 'Jaipur',
          rating: 5,
          comment: 'Wore this for my brother’s sangeet—razor-sharp tailoring and rich silk texture.',
          date: '2026-11-05',
          verified: true,
        },
        {
          id: 'rev-9',
          userName: 'Nikhil Verma',
          city: 'Chandigarh',
          rating: 5,
          comment: 'Looks bespoke right out of the garment bag.',
          date: '2026-11-14',
          verified: true,
        },
      ],
      collections: ['Best Sellers', 'Featured', 'Trending'],
      createdAt: now,
    },
    {
      id: 'prod-chanderi-kurti',
      slug: 'chanderi-embroidered-straight-kurti-set',
      sku: 'VA-W-KRT-007',
      name: 'Chanderi Embroidered Straight Kurti Set',
      category: "Women's Fashion",
      subcategory: 'Kurtis',
      description:
        'Handwoven mist-grey Chanderi silk-cotton straight kurti adorned with delicate resham embroidery along the yoke, paired with wide-leg trousers and an organza dupatta.',
      fabricCare: 'Chanderi Silk-Cotton with Mulmul Lining · Dry clean only',
      price: 4299,
      originalPrice: 5499,
      sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Mist Grey', hex: '#9CA3AF' },
        { name: 'Pearl Ivory', hex: '#EFECE6' },
      ],
      images: ['/src/assets/images/womens_chanderi_kurti_1795244907739.jpg'],
      stock: 26,
      rating: 4.9,
      reviewCount: 2,
      reviews: [
        {
          id: 'rev-10',
          userName: 'Ananya Iyer',
          city: 'Chennai',
          rating: 5,
          comment: 'Breathable mulmul lining makes it comfortable all day at festive gatherings.',
          date: '2026-11-07',
          verified: true,
        },
        {
          id: 'rev-11',
          userName: 'Meera Krishnan',
          city: 'Mumbai',
          rating: 5,
          comment: 'Understated elegance—the silver threadwork is subtle and refined.',
          date: '2026-11-13',
          verified: true,
        },
      ],
      collections: ['New Arrivals', 'Best Sellers', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-colaba-dress',
      slug: 'colaba-belted-cotton-poplin-midi-dress',
      sku: 'VA-W-DRS-008',
      name: 'Colaba Belted Cotton-Poplin Midi Dress',
      category: "Women's Fashion",
      subcategory: 'Dresses',
      description:
        'Architectural A-line shirt dress cut from crisp high-twist cotton poplin with a removable tonal buckle belt, side-seam pockets, and cuffed full sleeves.',
      fabricCare: '100% Combed Cotton Poplin · Machine wash cold gentle',
      price: 4799,
      originalPrice: 5999,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: [
        { name: 'Slate Blue', hex: '#4B637D' },
        { name: 'Deep Ink', hex: '#1F2937' },
      ],
      images: ['/src/assets/images/womens_evening_dress_1795244910895.jpg'],
      stock: 30,
      rating: 4.8,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-12',
          userName: 'Rhea Chatterjee',
          city: 'New Delhi',
          rating: 5,
          comment: 'Structured yet effortless. Easily transitions from client meetings to dinner.',
          date: '2026-11-09',
          verified: true,
        },
      ],
      collections: ['New Arrivals', 'Trending', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-ivory-peplum-top',
      slug: 'ivory-draped-silk-blend-top',
      sku: 'VA-W-TOP-009',
      name: 'Ivory Draped Silk-Blend Top',
      category: "Women's Fashion",
      subcategory: 'Tops',
      description:
        'Sleeveless asymmetric draped blouse tailored in luminous viscose-silk crepe with clean French seams and concealed back closure.',
      fabricCare: '70% Viscose, 30% Mulberry Silk · Dry clean or cold hand wash',
      price: 2799,
      originalPrice: 3499,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: [
        { name: 'Soft Ivory', hex: '#F3F0E8' },
        { name: 'Obsidian', hex: '#18181B' },
      ],
      images: ['/src/assets/images/hero_fashion_models_1795244904362.jpg'],
      stock: 34,
      rating: 4.7,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-13',
          userName: 'Tara Singhania',
          city: 'Mumbai',
          rating: 5,
          comment: 'Drapes cleanly without clinging. Pairs wonderfully with high-waist trousers.',
          date: '2026-11-01',
          verified: true,
        },
      ],
      collections: ['Trending'],
      createdAt: now,
    },
    {
      id: 'prod-banarasi-saree',
      slug: 'varanasi-midnight-silver-zari-banarasi-saree',
      sku: 'VA-W-SAR-010',
      name: 'Varanasi Midnight Silver-Zari Banarasi Saree',
      category: "Women's Fashion",
      subcategory: 'Sarees',
      description:
        'Heirloom handloom Katan silk saree woven by master weavers in Varanasi, featuring a deep midnight navy body accented with fine silver-tested zari motifs and pallu.',
      fabricCare: '100% Pure Handloom Katan Silk · Dry clean only · Store wrapped in muslin',
      price: 14999,
      originalPrice: 18500,
      sizes: ['One Size'],
      colors: [
        { name: 'Midnight Navy & Silver', hex: '#162447' },
        { name: 'Slate Charcoal', hex: '#334155' },
      ],
      images: ['/src/assets/images/womens_banarasi_saree_1795244907898.jpg'],
      stock: 9,
      rating: 5.0,
      reviewCount: 2,
      reviews: [
        {
          id: 'rev-14',
          userName: 'Nandini Kulkarni',
          city: 'Pune',
          rating: 5,
          comment: 'The silver zari has an understated glow rather than harsh shine. True heirloom piece.',
          date: '2026-11-03',
          verified: true,
        },
        {
          id: 'rev-15',
          userName: 'Kavya Menon',
          city: 'Bengaluru',
          rating: 5,
          comment: 'Lightweight Katan silk drapes like water and includes an unstitched matching blouse piece.',
          date: '2026-11-15',
          verified: true,
        },
      ],
      collections: ['Best Sellers', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-womens-indigo-denim',
      slug: 'high-rise-relaxed-indigo-denim',
      sku: 'VA-W-JNS-011',
      name: 'High-Rise Relaxed Indigo Denim',
      category: "Women's Fashion",
      subcategory: 'Jeans',
      description:
        'Tailored high-rise straight-leg jeans crafted from breathable organic cotton denim with clean tonal stitching and contoured waistband.',
      fabricCare: '99% Organic Cotton, 1% Elastane · Machine wash cold inside out',
      price: 3799,
      originalPrice: 4699,
      sizes: ['XS', 'S', 'M', 'L', 'XL'],
      colors: [
        { name: 'Classic Indigo', hex: '#263859' },
        { name: 'Charcoal Wash', hex: '#2D3136' },
      ],
      images: ['/src/assets/images/mens_oversized_tee_1795244906110.jpg'],
      stock: 27,
      rating: 4.6,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-16',
          userName: 'Zoya Merchant',
          city: 'Ahmedabad',
          rating: 5,
          comment: 'Finally a high-rise fit with zero waist gap and sturdy pockets.',
          date: '2026-11-06',
          verified: true,
        },
      ],
      collections: ['New Arrivals'],
      createdAt: now,
    },
    {
      id: 'prod-jaipur-festive-ethnic',
      slug: 'jaipur-festive-handloom-ethnic-ensemble',
      sku: 'VA-W-ETH-012',
      name: 'Jaipur Festive Handloom Ethnic Ensemble',
      category: "Women's Fashion",
      subcategory: 'Ethnic Wear',
      description:
        'Three-piece festive kurta set woven with subtle metallic tissue stripes, paired with relaxed culottes and a sheer scalloped border dupatta.',
      fabricCare: 'Silk-Blend Tissue · Dry clean only',
      price: 7499,
      originalPrice: 9299,
      sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
      colors: [
        { name: 'Silver Mist', hex: '#CBD5E1' },
        { name: 'Midnight Slate', hex: '#1E293B' },
      ],
      images: ['/src/assets/images/womens_chanderi_kurti_1795244907739.jpg'],
      stock: 14,
      rating: 4.9,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-17',
          userName: 'Ishita Bose',
          city: 'Kolkata',
          rating: 5,
          comment: 'Effortlessly regal for intimate Diwali and wedding celebrations.',
          date: '2026-11-12',
          verified: true,
        },
      ],
      collections: ['Trending', 'Best Sellers'],
      createdAt: now,
    },
    {
      id: 'prod-sovereign-watch',
      slug: 'sovereign-brushed-steel-chronograph',
      sku: 'VA-A-WCH-013',
      name: 'Sovereign Brushed Steel Chronograph',
      category: 'Accessories',
      subcategory: 'Watches',
      description:
        '40mm 316L brushed surgical stainless steel case with sapphire-coated crystal, sunray midnight-navy dial, dual sub-dials, and vegetable-tanned leather strap.',
      fabricCare: '5 ATM Water Resistant · Wipe case with dry microfiber cloth',
      price: 11999,
      originalPrice: 14999,
      sizes: ['One Size'],
      colors: [
        { name: 'Midnight Navy / Steel', hex: '#1E2B48' },
        { name: 'Obsidian / Steel', hex: '#18181B' },
      ],
      images: ['/src/assets/images/acc_chronograph_watch_1795244907741.jpg'],
      stock: 19,
      rating: 4.9,
      reviewCount: 2,
      reviews: [
        {
          id: 'rev-18',
          userName: 'Karan Mehta',
          city: 'Mumbai',
          rating: 5,
          comment: 'The brushed finishing and crisp navy dial punch well above its price bracket.',
          date: '2026-11-04',
          verified: true,
        },
        {
          id: 'rev-19',
          userName: 'Aditya Rao',
          city: 'Hyderabad',
          rating: 5,
          comment: 'Supple leather strap right out of the presentation box.',
          date: '2026-11-16',
          verified: true,
        },
      ],
      collections: ['New Arrivals', 'Best Sellers', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-bandra-tote',
      slug: 'bandra-full-grain-pebble-leather-tote',
      sku: 'VA-A-BAG-014',
      name: 'Bandra Full-Grain Pebble Leather Tote',
      category: 'Accessories',
      subcategory: 'Bags',
      description:
        'Architectural structured work tote handcrafted from Indian full-grain pebble leather with padded 14-inch laptop sleeve, solid nickel hardware, and cotton-twill lining.',
      fabricCare: '100% Full-Grain Leather · Condition seasonally · Store in dust bag',
      price: 7999,
      originalPrice: 9999,
      sizes: ['One Size'],
      colors: [
        { name: 'Obsidian Black', hex: '#111315' },
        { name: 'Deep Slate', hex: '#334155' },
      ],
      images: ['/src/assets/images/acc_leather_tote_belt_1795244908804.jpg'],
      stock: 16,
      rating: 4.9,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-20',
          userName: 'Shruti Nair',
          city: 'Bengaluru',
          rating: 5,
          comment: 'Fits my MacBook Pro, charger, and notebook while keeping its sharp silhouette.',
          date: '2026-11-10',
          verified: true,
        },
      ],
      collections: ['Trending', 'Featured'],
      createdAt: now,
    },
    {
      id: 'prod-bridle-belt',
      slug: 'reversible-bridle-leather-dress-belt',
      sku: 'VA-A-BLT-015',
      name: 'Reversible Bridle Leather Dress Belt',
      category: 'Accessories',
      subcategory: 'Belts',
      description:
        'Two-in-one black and espresso reversible full-grain bridle leather belt paired with a twist-lock brushed stainless steel buckle.',
      fabricCare: '100% Vegetable-Tanned Leather · Avoid direct moisture',
      price: 2299,
      originalPrice: 2899,
      sizes: ['S', 'M', 'L', 'XL'],
      colors: [{ name: 'Black / Espresso Reversible', hex: '#1F1B18' }],
      images: ['/src/assets/images/acc_leather_tote_belt_1795244908804.jpg'],
      stock: 40,
      rating: 4.7,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-21',
          userName: 'Harshvardhan Roy',
          city: 'Gurgaon',
          rating: 5,
          comment: 'Smooth twist mechanism and crisp edge paint.',
          date: '2026-11-08',
          verified: true,
        },
      ],
      collections: ['Best Sellers'],
      createdAt: now,
    },
    {
      id: 'prod-minimalist-cuff-set',
      slug: 'minimalist-steel-leather-accessory-kit',
      sku: 'VA-A-ACC-016',
      name: 'Atelier Steel & Leather Valet Duo',
      category: 'Accessories',
      subcategory: 'Fashion Accessories',
      description:
        'Curated gifting duo combining our brushed steel collar stays, minimalist cardholder, and hand-stitched watch strap travel pouch.',
      fabricCare: 'Brushed 316L Steel & Full-Grain Leather · Wipe clean',
      price: 1899,
      originalPrice: 2499,
      sizes: ['One Size'],
      colors: [
        { name: 'Midnight Navy', hex: '#1E2B48' },
        { name: 'Obsidian', hex: '#111315' },
      ],
      images: ['/src/assets/images/acc_chronograph_watch_1795244907741.jpg'],
      stock: 32,
      rating: 4.8,
      reviewCount: 1,
      reviews: [
        {
          id: 'rev-22',
          userName: 'Neha Parekh',
          city: 'Surat',
          rating: 5,
          comment: 'Bought this as an anniversary gift—minimalist packaging and top-notch finish.',
          date: '2026-11-13',
          verified: true,
        },
      ],
      collections: ['New Arrivals'],
      createdAt: now,
    },
  ];
}

function createInitialStore(): StoreData {
  const adminId = 'usr-admin-1';
  const customerId = 'usr-cust-1';
  const customerAddress: ShippingAddress = {
    fullName: 'Aarav Sharma',
    phone: '9820411290',
    email: 'aarav.sharma@example.in',
    street: '402 Sea Breeze Apartments, Carter Road, Bandra West',
    city: 'Mumbai',
    state: 'Maharashtra',
    pinCode: '400050',
  };

  const products = seedProducts();

  return {
    authSecret: crypto.randomBytes(32).toString('hex'),
    users: [
      {
        id: adminId,
        name: 'Vastra Atelier Admin',
        email: 'admin@vastraatelier.in',
        phone: '9819000100',
        role: 'admin',
        passwordHash: hashPassword('Admin@123'),
        createdAt: '2026-10-01T09:00:00.000Z',
      },
      {
        id: customerId,
        name: 'Aarav Sharma',
        email: 'aarav.sharma@example.in',
        phone: '9820411290',
        role: 'customer',
        passwordHash: hashPassword('Customer@123'),
        createdAt: '2026-10-18T11:20:00.000Z',
        defaultAddress: customerAddress,
      },
    ],
    products,
    orders: [
      {
        id: 'ORD-VA-26101',
        userId: customerId,
        customerName: 'Aarav Sharma',
        customerEmail: 'aarav.sharma@example.in',
        items: [
          {
            productId: 'prod-nawab-nehru-set',
            name: 'Nawab Midnight Silk Nehru Jacket & Kurta Set',
            image: '/src/assets/images/mens_kurta_jacket_1795244907561.jpg',
            size: 'L',
            color: 'Midnight Indigo',
            quantity: 1,
            price: 8999,
          },
        ],
        shippingAddress: customerAddress,
        subtotal: 8999,
        discount: 1350,
        couponCode: 'WELCOME15',
        shippingFee: 0,
        total: 7649,
        paymentMethod: 'UPI',
        paymentStatus: 'Paid',
        razorpayOrderId: 'order_test_VA26101',
        razorpayPaymentId: 'pay_test_9918273',
        status: 'Delivered',
        createdAt: '2026-11-04T14:32:00.000Z',
        updatedAt: '2026-11-08T16:10:00.000Z',
      },
      {
        id: 'ORD-VA-26102',
        userId: customerId,
        customerName: 'Ananya Iyer',
        customerEmail: 'ananya.iyer@example.in',
        items: [
          {
            productId: 'prod-banarasi-saree',
            name: 'Varanasi Midnight Silver-Zari Banarasi Saree',
            image: '/src/assets/images/womens_banarasi_saree_1795244907898.jpg',
            size: 'One Size',
            color: 'Midnight Navy & Silver',
            quantity: 1,
            price: 14999,
          },
        ],
        shippingAddress: {
          fullName: 'Ananya Iyer',
          phone: '9840123456',
          email: 'ananya.iyer@example.in',
          street: '18 Poes Garden Road, Teynampet',
          city: 'Chennai',
          state: 'Tamil Nadu',
          pinCode: '600086',
        },
        subtotal: 14999,
        discount: 2999,
        couponCode: 'VASTRA20',
        shippingFee: 0,
        total: 12000,
        paymentMethod: 'CARD',
        paymentStatus: 'Paid',
        razorpayOrderId: 'order_test_VA26102',
        razorpayPaymentId: 'pay_test_8831029',
        status: 'Shipped',
        createdAt: '2026-11-16T09:15:00.000Z',
        updatedAt: '2026-11-18T11:45:00.000Z',
      },
      {
        id: 'ORD-VA-26103',
        userId: customerId,
        customerName: 'Rohan Malhotra',
        customerEmail: 'rohan.m@example.in',
        items: [
          {
            productId: 'prod-sovereign-watch',
            name: 'Sovereign Brushed Steel Chronograph',
            image: '/src/assets/images/acc_chronograph_watch_1795244907741.jpg',
            size: 'One Size',
            color: 'Midnight Navy / Steel',
            quantity: 1,
            price: 11999,
          },
          {
            productId: 'prod-kora-tee',
            name: 'Kora Heavyweight Supima Tee',
            image: '/src/assets/images/mens_oversized_tee_1795244906110.jpg',
            size: 'M',
            color: 'Obsidian Charcoal',
            quantity: 2,
            price: 1999,
          },
        ],
        shippingAddress: {
          fullName: 'Rohan Malhotra',
          phone: '9910099100',
          email: 'rohan.m@example.in',
          street: 'B-44 Defence Colony',
          city: 'New Delhi',
          state: 'Delhi',
          pinCode: '110024',
        },
        subtotal: 15997,
        discount: 1000,
        couponCode: 'FESTIVE1000',
        shippingFee: 0,
        total: 14997,
        paymentMethod: 'COD',
        paymentStatus: 'Pending COD',
        status: 'Confirmed',
        createdAt: '2026-11-19T18:20:00.000Z',
        updatedAt: '2026-11-20T08:05:00.000Z',
      },
    ],
    coupons: [
      {
        code: 'WELCOME15',
        description: '15% off on your first order (max ₹2,000)',
        type: 'percent',
        value: 15,
        minOrder: 1499,
        maxDiscount: 2000,
        firstOrderOnly: false,
      },
      {
        code: 'VASTRA20',
        description: '20% off on orders above ₹6,000 (max ₹3,500)',
        type: 'percent',
        value: 20,
        minOrder: 6000,
        maxDiscount: 3500,
      },
      {
        code: 'FESTIVE1000',
        description: 'Flat ₹1,000 off on orders above ₹4,999',
        type: 'flat',
        value: 1000,
        minOrder: 4999,
      },
    ],
    wishlists: {
      [customerId]: ['prod-alibaug-linen', 'prod-sovereign-watch'],
    },
    newsletterSubscribers: [
      { email: 'aarav.sharma@example.in', subscribedAt: '2026-10-18T11:25:00.000Z' },
    ],
  };
}

let cachedStore: StoreData | null = null;

export function ensureDataDirs() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
}

export function getStore(): StoreData {
  if (cachedStore) return cachedStore;
  ensureDataDirs();
  if (fs.existsSync(STORE_PATH)) {
    try {
      const raw = fs.readFileSync(STORE_PATH, 'utf-8');
      cachedStore = JSON.parse(raw) as StoreData;
      return cachedStore;
    } catch {
      // Fallback to fresh seed if corrupted
    }
  }
  cachedStore = createInitialStore();
  saveStore(cachedStore);
  return cachedStore;
}

export function saveStore(data: StoreData): void {
  ensureDataDirs();
  cachedStore = data;
  const tmpPath = `${STORE_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmpPath, STORE_PATH);
}

export function sanitizeUser(user: StoredUser): UserProfile {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    role: user.role,
    createdAt: user.createdAt,
    defaultAddress: user.defaultAddress,
  };
}

export function signToken(userId: string, role: UserRole): string {
  const store = getStore();
  const payload = Buffer.from(
    JSON.stringify({
      sub: userId,
      role,
      exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
    }),
  ).toString('base64url');
  const sig = crypto
    .createHmac('sha256', store.authSecret)
    .update(payload)
    .digest('base64url');
  return `${payload}.${sig}`;
}

export function verifyToken(token: string): { sub: string; role: UserRole } | null {
  const store = getStore();
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expectedSig = crypto
    .createHmac('sha256', store.authSecret)
    .update(payload)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8')) as {
      sub: string;
      role: UserRole;
      exp: number;
    };
    if (decoded.exp < Date.now()) return null;
    return { sub: decoded.sub, role: decoded.role };
  } catch {
    return null;
  }
}

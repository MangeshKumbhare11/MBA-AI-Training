import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import type { CartItem, Product, ProductSize, UserProfile } from '../types.ts';

interface ToastMessage {
  id: number;
  text: string;
  tone: 'neutral' | 'success' | 'error';
}

interface StoreContextValue {
  products: Product[];
  productsLoading: boolean;
  productsError: string | null;
  refreshProducts: () => Promise<void>;
  user: UserProfile | null;
  token: string | null;
  authLoading: boolean;
  login: (email: string, password: string) => Promise<UserProfile>;
  register: (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
  }) => Promise<UserProfile>;
  logout: () => void;
  cart: CartItem[];
  cartCount: number;
  cartSubtotal: number;
  addToCart: (
    product: Product,
    size: ProductSize,
    color: string,
    quantity?: number,
    openDrawer?: boolean,
  ) => void;
  updateCartQuantity: (
    productId: string,
    size: ProductSize,
    color: string,
    quantity: number,
  ) => void;
  removeFromCart: (productId: string, size: ProductSize, color: string) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  wishlistIds: string[];
  toggleWishlist: (productId: string) => Promise<void>;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;
  notify: (text: string, tone?: 'neutral' | 'success' | 'error') => void;
}

const StoreContext = createContext<StoreContextValue | null>(null);

const TOKEN_KEY = 'vastra_auth_token';
const CART_KEY = 'vastra_cart_items';
const WISHLIST_KEY = 'vastra_guest_wishlist';

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [productsLoading, setProductsLoading] = useState(true);
  const [productsError, setProductsError] = useState<string | null>(null);

  const [token, setToken] = useState<string | null>(() =>
    localStorage.getItem(TOKEN_KEY),
  );
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(Boolean(localStorage.getItem(TOKEN_KEY)));

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(WISHLIST_KEY);
      return saved ? (JSON.parse(saved) as string[]) : [];
    } catch {
      return [];
    }
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const notify = useCallback(
    (text: string, tone: 'neutral' | 'success' | 'error' = 'neutral') => {
      const id = Date.now() + Math.floor(Math.random() * 1000);
      setToasts((prev) => [...prev.slice(-2), { id, text, tone }]);
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3400);
    },
    [],
  );

  const refreshProducts = useCallback(async () => {
    try {
      setProductsError(null);
      const res = await fetch('/api/products');
      if (!res.ok) throw new Error('Unable to load products.');
      const data = (await res.json()) as { products: Product[] };
      setProducts(data.products);
    } catch (err) {
      setProductsError(
        err instanceof Error ? err.message : 'Failed to load store catalog.',
      );
    } finally {
      setProductsLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshProducts();
  }, [refreshProducts]);

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (!token) {
      localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlistIds));
    }
  }, [wishlistIds, token]);

  useEffect(() => {
    if (!token) {
      setUser(null);
      setAuthLoading(false);
      return;
    }

    let cancelled = false;
    setAuthLoading(true);
    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(async (res) => {
        if (!res.ok) throw new Error('Session expired');
        return (await res.json()) as { user: UserProfile };
      })
      .then(async ({ user: profile }) => {
        if (cancelled) return;
        setUser(profile);
        const wRes = await fetch('/api/wishlist', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (wRes.ok && !cancelled) {
          const wData = (await wRes.json()) as { productIds: string[] };
          setWishlistIds(wData.productIds);
        }
      })
      .catch(() => {
        if (!cancelled) {
          localStorage.removeItem(TOKEN_KEY);
          setToken(null);
          setUser(null);
        }
      })
      .finally(() => {
        if (!cancelled) setAuthLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [token]);

  const login = useCallback(async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = (await res.json()) as {
      token?: string;
      user?: UserProfile;
      error?: string;
    };
    if (!res.ok || !data.token || !data.user) {
      throw new Error(data.error || 'Sign in failed.');
    }
    localStorage.setItem(TOKEN_KEY, data.token);
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const register = useCallback(
    async (payload: {
      name: string;
      email: string;
      phone: string;
      password: string;
    }) => {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as {
        token?: string;
        user?: UserProfile;
        error?: string;
      };
      if (!res.ok || !data.token || !data.user) {
        throw new Error(data.error || 'Registration failed.');
      }
      localStorage.setItem(TOKEN_KEY, data.token);
      setToken(data.token);
      setUser(data.user);
      return data.user;
    },
    [],
  );

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setUser(null);
    setWishlistIds([]);
    notify('Signed out of your account.', 'neutral');
  }, [notify]);

  const addToCart = useCallback(
    (
      product: Product,
      size: ProductSize,
      color: string,
      quantity = 1,
      openDrawer = true,
    ) => {
      if (product.stock <= 0) {
        notify('This item is currently out of stock.', 'error');
        return;
      }
      setCart((prev) => {
        const idx = prev.findIndex(
          (i) => i.productId === product.id && i.size === size && i.color === color,
        );
        if (idx >= 0) {
          const updated = [...prev];
          const nextQty = Math.min(product.stock, updated[idx].quantity + quantity);
          updated[idx] = { ...updated[idx], quantity: nextQty, maxStock: product.stock };
          return updated;
        }
        return [
          ...prev,
          {
            productId: product.id,
            name: product.name,
            price: product.price,
            originalPrice: product.originalPrice,
            image: product.images[0] || '',
            size,
            color,
            quantity: Math.min(product.stock, quantity),
            maxStock: product.stock,
            category: product.category,
          },
        ];
      });
      notify(`Added ${product.name} (${size}) to your bag.`, 'success');
      if (openDrawer) setIsCartOpen(true);
    },
    [notify],
  );

  const updateCartQuantity = useCallback(
    (productId: string, size: ProductSize, color: string, quantity: number) => {
      setCart((prev) => {
        if (quantity <= 0) {
          return prev.filter(
            (i) => !(i.productId === productId && i.size === size && i.color === color),
          );
        }
        return prev.map((i) =>
          i.productId === productId && i.size === size && i.color === color
            ? { ...i, quantity: Math.min(i.maxStock, quantity) }
            : i,
        );
      });
    },
    [],
  );

  const removeFromCart = useCallback(
    (productId: string, size: ProductSize, color: string) => {
      setCart((prev) =>
        prev.filter(
          (i) => !(i.productId === productId && i.size === size && i.color === color),
        ),
      );
    },
    [],
  );

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const toggleWishlist = useCallback(
    async (productId: string) => {
      if (token) {
        const res = await fetch('/api/wishlist/toggle', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ productId }),
        });
        if (res.ok) {
          const data = (await res.json()) as { productIds: string[] };
          const added = data.productIds.includes(productId);
          setWishlistIds(data.productIds);
          notify(
            added ? 'Saved to your wishlist.' : 'Removed from your wishlist.',
            'neutral',
          );
          return;
        }
      }
      setWishlistIds((prev) => {
        const exists = prev.includes(productId);
        const next = exists
          ? prev.filter((id) => id !== productId)
          : [...prev, productId];
        notify(
          exists ? 'Removed from your wishlist.' : 'Saved to your wishlist.',
          'neutral',
        );
        return next;
      });
    },
    [token, notify],
  );

  const cartCount = useMemo(
    () => cart.reduce((sum, i) => sum + i.quantity, 0),
    [cart],
  );
  const cartSubtotal = useMemo(
    () => cart.reduce((sum, i) => sum + i.price * i.quantity, 0),
    [cart],
  );

  return (
    <StoreContext.Provider
      value={{
        products,
        productsLoading,
        productsError,
        refreshProducts,
        user,
        token,
        authLoading,
        login,
        register,
        logout,
        cart,
        cartCount,
        cartSubtotal,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        wishlistIds,
        toggleWishlist,
        isAuthModalOpen,
        setIsAuthModalOpen,
        notify,
      }}
    >
      {children}
      {/* Subtle bottom-left toast stack */}
      {toasts.length > 0 && (
        <div
          aria-live="polite"
          className="fixed bottom-5 left-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none"
        >
          {toasts.map((toast) => (
            <div
              key={toast.id}
              className={`pointer-events-auto px-4 py-3 text-sm font-medium rounded-lg shadow-lg border transition-all duration-200 ${
                toast.tone === 'error'
                  ? 'bg-[#FEF2F2] text-[#991B1B] border-[#FECACA]'
                  : toast.tone === 'success'
                    ? 'bg-[#111315] text-white border-[#27272A]'
                    : 'bg-white text-[#111315] border-[#E2E8F0]'
              }`}
            >
              {toast.text}
            </div>
          ))}
        </div>
      )}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside StoreProvider');
  return ctx;
}

import {
  Banknote,
  Building2,
  CheckCircle2,
  CreditCard,
  ShieldCheck,
  Smartphone,
  Tag,
} from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type { Order, PaymentMethod, ShippingAddress } from '../types.ts';
import { formatINR, INDIAN_STATES } from '../utils/format.ts';
import { RazorpayModal } from './RazorpayModal.tsx';
import { ResilientImage } from './ResilientImage.tsx';

interface CheckoutPageProps {
  onContinueShopping: () => void;
  onViewOrderHistory: () => void;
}

export function CheckoutPage({
  onContinueShopping,
  onViewOrderHistory,
}: CheckoutPageProps) {
  const {
    cart,
    cartSubtotal,
    user,
    token,
    clearCart,
    refreshProducts,
    notify,
  } = useStore();

  const [address, setAddress] = useState<ShippingAddress>({
    fullName: user?.defaultAddress?.fullName || user?.name || '',
    phone: user?.defaultAddress?.phone || user?.phone || '',
    email: user?.defaultAddress?.email || user?.email || '',
    street: user?.defaultAddress?.street || '',
    city: user?.defaultAddress?.city || '',
    state: user?.defaultAddress?.state || 'Maharashtra',
    pinCode: user?.defaultAddress?.pinCode || '',
  });

  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<{
    code: string;
    discount: number;
  } | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [placingOrder, setPlacingOrder] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  // Razorpay modal state
  const [rzpOpen, setRzpOpen] = useState(false);
  const [rzpOrderId, setRzpOrderId] = useState('');

  const discount = appliedCoupon ? appliedCoupon.discount : 0;
  const afterDiscount = Math.max(0, cartSubtotal - discount);
  const shippingFee = afterDiscount >= 2999 || cart.length === 0 ? 0 : 149;
  const grandTotal = afterDiscount + shippingFee;

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError(null);
    if (!couponInput.trim()) return;
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponInput, subtotal: cartSubtotal }),
      });
      const data = (await res.json()) as {
        valid?: boolean;
        code?: string;
        discount?: number;
        error?: string;
      };
      if (!res.ok || !data.code) {
        throw new Error(data.error || 'Coupon not valid.');
      }
      setAppliedCoupon({ code: data.code, discount: data.discount || 0 });
      notify(`Coupon ${data.code} applied.`, 'success');
    } catch (err) {
      setAppliedCoupon(null);
      setCouponError(err instanceof Error ? err.message : 'Invalid coupon.');
    }
  };

  const finalizeOrder = async (razorpayPaymentId?: string) => {
    setPlacingOrder(true);
    setCheckoutError(null);
    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          items: cart.map((i) => ({
            productId: i.productId,
            size: i.size,
            color: i.color,
            quantity: i.quantity,
          })),
          shippingAddress: address,
          paymentMethod,
          couponCode: appliedCoupon?.code,
          razorpayOrderId: rzpOrderId || undefined,
          razorpayPaymentId,
        }),
      });
      const data = (await res.json()) as { order?: Order; error?: string };
      if (!res.ok || !data.order) {
        throw new Error(data.error || 'Could not place your order.');
      }
      setConfirmedOrder(data.order);
      clearCart();
      await refreshProducts();
      notify(`Order ${data.order.id} confirmed!`, 'success');
    } catch (err) {
      setCheckoutError(
        err instanceof Error ? err.message : 'Order creation failed.',
      );
    } finally {
      setPlacingOrder(false);
    }
  };

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutError(null);

    if (!/^\d{6}$/.test(address.pinCode.trim())) {
      setCheckoutError('Please enter a valid 6-digit Indian PIN code.');
      return;
    }

    if (paymentMethod === 'COD') {
      await finalizeOrder();
      return;
    }

    setPlacingOrder(true);
    try {
      const res = await fetch('/api/payments/razorpay/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: grandTotal }),
      });
      const data = (await res.json()) as {
        razorpayOrderId?: string;
        error?: string;
      };
      if (!res.ok || !data.razorpayOrderId) {
        throw new Error(data.error || 'Unable to initialize Razorpay.');
      }
      setRzpOrderId(data.razorpayOrderId);
      setRzpOpen(true);
    } catch (err) {
      setCheckoutError(
        err instanceof Error ? err.message : 'Payment initialization failed.',
      );
    } finally {
      setPlacingOrder(false);
    }
  };

  if (confirmedOrder) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="bg-white border border-[#E2E8F0] rounded-xl p-8 sm:p-10 space-y-6">
          <div className="flex items-start gap-4">
            <CheckCircle2 className="w-9 h-9 text-[#166534] shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#64748B]">
                Order Confirmation
              </p>
              <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
                Order #{confirmedOrder.id} Confirmed
              </h1>
              <p className="text-sm text-[#475569] mt-2">
                Thank you, {confirmedOrder.customerName}. Your pieces are being
                prepared for insured dispatch to {confirmedOrder.shippingAddress.city},{' '}
                {confirmedOrder.shippingAddress.state}.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-[#F8F9FA] border border-[#E2E8F0] rounded-lg text-xs">
            <div>
              <p className="text-[#64748B]">Order Status</p>
              <p className="font-semibold text-[#111315] mt-0.5">
                {confirmedOrder.status}
              </p>
            </div>
            <div>
              <p className="text-[#64748B]">Payment</p>
              <p className="font-semibold text-[#111315] mt-0.5">
                {confirmedOrder.paymentMethod} · {confirmedOrder.paymentStatus}
              </p>
            </div>
            <div>
              <p className="text-[#64748B]">Total Amount</p>
              <p className="font-semibold text-[#111315] tabular-nums mt-0.5">
                {formatINR(confirmedOrder.total)}
              </p>
            </div>
          </div>

          <div className="divide-y divide-[#F1F5F9] border-y border-[#E2E8F0]">
            {confirmedOrder.items.map((item, idx) => (
              <div key={idx} className="py-3.5 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded bg-[#F1F3F5] overflow-hidden shrink-0">
                    <ResilientImage
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-[#111315] truncate">
                      {item.name}
                    </p>
                    <p className="text-xs text-[#64748B]">
                      Size {item.size} · {item.color} · Qty {item.quantity}
                    </p>
                  </div>
                </div>
                <span className="text-sm font-semibold text-[#111315] tabular-nums">
                  {formatINR(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-3">
            {user && (
              <button
                type="button"
                onClick={onViewOrderHistory}
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
              >
                View Order History
              </button>
            )}
            <button
              type="button"
              onClick={onContinueShopping}
              className="px-5 py-2.5 text-sm font-medium text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md cursor-pointer"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <h1 className="font-editorial text-3xl font-semibold text-[#111315]">
          Your bag is empty
        </h1>
        <p className="text-sm text-[#64748B] mt-2">
          Add garments or accessories to your bag before proceeding to checkout.
        </p>
        <button
          type="button"
          onClick={onContinueShopping}
          className="mt-6 px-6 py-3 text-sm font-semibold text-white bg-[#111315] rounded-md cursor-pointer"
        >
          Browse Storefront
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="pb-6 border-b border-[#E2E8F0]">
        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
          Secure Indian Checkout
        </p>
        <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
          Shipping &amp; Payment
        </h1>
      </div>

      <form
        onSubmit={handleCheckoutSubmit}
        className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
      >
        {/* Left: Shipping & Payment Options */}
        <div className="lg:col-span-7 space-y-6">
          {checkoutError && (
            <div className="p-4 text-sm font-medium text-[#991B1B] bg-[#FEF2F2] border border-[#FECACA] rounded-lg">
              {checkoutError}
            </div>
          )}

          {/* Shipping Address */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-6 space-y-4">
            <h2 className="font-sans text-base font-semibold text-[#111315]">
              1. Delivery Address
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={address.fullName}
                  onChange={(e) =>
                    setAddress({ ...address, fullName: e.target.value })
                  }
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  Mobile Number
                </label>
                <input
                  type="tel"
                  required
                  value={address.phone}
                  onChange={(e) =>
                    setAddress({ ...address, phone: e.target.value })
                  }
                  placeholder="9820011223"
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                Email Address (for order confirmation &amp; GST invoice)
              </label>
              <input
                type="email"
                required
                value={address.email}
                onChange={(e) =>
                  setAddress({ ...address, email: e.target.value })
                }
                className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                House / Flat No., Building, Street, Landmark
              </label>
              <input
                type="text"
                required
                value={address.street}
                onChange={(e) =>
                  setAddress({ ...address, street: e.target.value })
                }
                placeholder="402 Sea Breeze Apartments, Bandra West"
                className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  City
                </label>
                <input
                  type="text"
                  required
                  value={address.city}
                  onChange={(e) =>
                    setAddress({ ...address, city: e.target.value })
                  }
                  placeholder="Mumbai"
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  State
                </label>
                <select
                  value={address.state}
                  onChange={(e) =>
                    setAddress({ ...address, state: e.target.value })
                  }
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md bg-white"
                >
                  {INDIAN_STATES.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  PIN Code
                </label>
                <input
                  type="text"
                  required
                  maxLength={6}
                  value={address.pinCode}
                  onChange={(e) =>
                    setAddress({
                      ...address,
                      pinCode: e.target.value.replace(/\D/g, ''),
                    })
                  }
                  placeholder="400050"
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md tabular-nums"
                />
              </div>
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-sans text-base font-semibold text-[#111315]">
                2. Payment Option
              </h2>
              <span className="text-xs text-[#64748B] flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#1E2B48]" />
                Razorpay Test Mode Ready
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                {
                  id: 'UPI' as const,
                  title: 'UPI (GPay, PhonePe, Paytm)',
                  desc: 'Instant verification via Razorpay',
                  icon: Smartphone,
                },
                {
                  id: 'CARD' as const,
                  title: 'Credit / Debit Cards',
                  desc: 'Visa, Mastercard, RuPay',
                  icon: CreditCard,
                },
                {
                  id: 'NETBANKING' as const,
                  title: 'Net Banking',
                  desc: 'HDFC, ICICI, SBI, Axis & more',
                  icon: Building2,
                },
                {
                  id: 'COD' as const,
                  title: 'Cash on Delivery (COD)',
                  desc: 'Pay in cash or UPI at your doorstep',
                  icon: Banknote,
                },
              ].map((opt) => {
                const Icon = opt.icon;
                const active = paymentMethod === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setPaymentMethod(opt.id)}
                    className={`p-4 text-left rounded-lg border transition-colors flex items-start gap-3 cursor-pointer ${
                      active
                        ? 'border-[#111315] bg-[#F8F9FA]'
                        : 'border-[#E2E8F0] hover:border-[#94A3B8]'
                    }`}
                  >
                    <Icon
                      className={`w-5 h-5 mt-0.5 shrink-0 ${
                        active ? 'text-[#111315]' : 'text-[#64748B]'
                      }`}
                    />
                    <div>
                      <p className="text-sm font-semibold text-[#111315]">
                        {opt.title}
                      </p>
                      <p className="text-xs text-[#64748B] mt-0.5">{opt.desc}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Order Summary */}
        <aside className="lg:col-span-5 bg-white border border-[#E2E8F0] rounded-lg p-6 space-y-5 lg:sticky lg:top-24">
          <h2 className="font-sans text-base font-semibold text-[#111315]">
            Order Summary ({cart.reduce((s, i) => s + i.quantity, 0)} items)
          </h2>

          <div className="divide-y divide-[#F1F5F9] max-h-72 overflow-y-auto pr-1">
            {cart.map((item) => (
              <div
                key={`${item.productId}-${item.size}-${item.color}`}
                className="py-3 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded bg-[#F1F3F5] overflow-hidden shrink-0">
                    <ResilientImage
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-[#111315] truncate">
                      {item.name}
                    </p>
                    <p className="text-[11px] text-[#64748B]">
                      {item.size} · {item.color} · Qty {item.quantity}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-semibold text-[#111315] tabular-nums">
                  {formatINR(item.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          {/* Coupon Code */}
          <div className="pt-4 border-t border-[#E2E8F0]">
            <p className="text-xs font-medium text-[#475569] flex items-center gap-1.5 mb-2">
              <Tag className="w-3.5 h-3.5" />
              Privilege / Discount Code (try WELCOME15)
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                placeholder="Enter coupon code"
                className="flex-1 px-3 py-2 text-xs font-mono uppercase border border-[#CBD5E1] rounded-md"
              />
              <button
                type="button"
                onClick={handleApplyCoupon}
                className="px-4 py-2 text-xs font-semibold text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md cursor-pointer"
              >
                Apply
              </button>
            </div>
            {couponError && (
              <p className="text-xs text-[#991B1B] mt-1.5">{couponError}</p>
            )}
            {appliedCoupon && (
              <p className="text-xs text-[#166534] font-medium mt-1.5">
                Applied {appliedCoupon.code}: saving {formatINR(appliedCoupon.discount)}
              </p>
            )}
          </div>

          <div className="pt-4 border-t border-[#E2E8F0] space-y-2 text-sm tabular-nums">
            <div className="flex justify-between text-[#475569]">
              <span>Subtotal</span>
              <span>{formatINR(cartSubtotal)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-[#166534]">
                <span>Coupon Discount ({appliedCoupon?.code})</span>
                <span>-{formatINR(discount)}</span>
              </div>
            )}
            <div className="flex justify-between text-[#475569]">
              <span>Shipping</span>
              <span>{shippingFee === 0 ? 'Complimentary' : formatINR(shippingFee)}</span>
            </div>
            <div className="flex justify-between text-base font-semibold text-[#111315] pt-2 border-t border-[#E2E8F0]">
              <span>Total Payable (incl. GST)</span>
              <span>{formatINR(grandTotal)}</span>
            </div>
          </div>

          <button
            type="submit"
            disabled={placingOrder}
            className="w-full py-3.5 px-4 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] disabled:opacity-60 rounded-md transition-colors cursor-pointer"
          >
            {placingOrder
              ? 'Processing...'
              : paymentMethod === 'COD'
                ? `Place COD Order (${formatINR(grandTotal)})`
                : `Continue to Razorpay (${formatINR(grandTotal)})`}
          </button>
        </aside>
      </form>

      <RazorpayModal
        open={rzpOpen}
        amount={grandTotal}
        razorpayOrderId={rzpOrderId}
        initialMethod={paymentMethod === 'COD' ? 'UPI' : paymentMethod}
        customerName={address.fullName}
        customerEmail={address.email}
        customerPhone={address.phone}
        onCancel={() => setRzpOpen(false)}
        onSuccess={(paymentId) => {
          setRzpOpen(false);
          void finalizeOrder(paymentId);
        }}
      />
    </div>
  );
}

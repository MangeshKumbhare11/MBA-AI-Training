import { Heart, ShoppingBag, Star } from 'lucide-react';
import { useStore } from '../context/StoreContext.tsx';
import type { Product } from '../types.ts';
import { discountPercent, formatINR } from '../utils/format.ts';
import { ResilientImage } from './ResilientImage.tsx';

interface ProductCardProps {
  product: Product;
  onSelect: (productId: string) => void;
}

export function ProductCard({ product, onSelect }: ProductCardProps) {
  const { wishlistIds, toggleWishlist, addToCart } = useStore();
  const isWishlisted = wishlistIds.includes(product.id);
  const pct = discountPercent(product.price, product.originalPrice);

  const subtleTag =
    product.stock === 0
      ? 'Sold Out'
      : pct >= 15
        ? `${pct}% Off`
        : product.collections.includes('New Arrivals')
          ? 'New Arrival'
          : null;

  return (
    <article className="group flex flex-col bg-white border border-[#E2E8F0] rounded-lg overflow-hidden transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      <div className="relative aspect-[4/3] bg-[#F1F3F5] overflow-hidden">
        <button
          type="button"
          onClick={() => onSelect(product.id)}
          className="block w-full h-full text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-[#111315]"
        >
          <ResilientImage
            src={product.images[0] || ''}
            alt={product.name}
            fallbackLabel={product.subcategory}
            className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.03]"
          />
        </button>

        {subtleTag && (
          <span className="absolute top-3 left-3 text-[11px] font-semibold tracking-wider uppercase text-[#111315] bg-white/90 px-2 py-0.5 rounded">
            {subtleTag}
          </span>
        )}

        <button
          type="button"
          onClick={() => void toggleWishlist(product.id)}
          aria-label={isWishlisted ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`}
          className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center rounded-full bg-white/90 text-[#111315] hover:bg-white transition-colors shadow-xs cursor-pointer"
        >
          <Heart
            className={`w-4 h-4 ${
              isWishlisted ? 'fill-[#1E2B48] text-[#1E2B48]' : 'text-[#475569]'
            }`}
          />
        </button>
      </div>

      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div>
          <p className="text-[11px] font-medium uppercase tracking-wider text-[#64748B] truncate">
            {product.category} · {product.subcategory}
          </p>
          <button
            type="button"
            onClick={() => onSelect(product.id)}
            className="mt-1 text-left text-[15px] font-semibold text-[#111315] hover:text-[#1E2B48] transition-colors line-clamp-1 cursor-pointer"
          >
            {product.name}
          </button>
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-baseline gap-2">
              <span className="text-[15px] font-semibold text-[#111315] tabular-nums">
                {formatINR(product.price)}
              </span>
              {product.originalPrice > product.price && (
                <span className="text-xs text-[#94A3B8] line-through tabular-nums">
                  {formatINR(product.originalPrice)}
                </span>
              )}
            </div>

            <div className="flex items-center gap-1 text-xs text-[#475569] tabular-nums">
              <Star className="w-3.5 h-3.5 fill-[#111315] text-[#111315]" />
              <span className="font-medium text-[#111315]">{product.rating.toFixed(1)}</span>
              <span>({product.reviewCount})</span>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2 border-t border-[#F1F5F9]">
            <button
              type="button"
              disabled={product.stock === 0}
              onClick={() =>
                addToCart(
                  product,
                  product.sizes[0] || 'M',
                  product.colors[0]?.name || 'Default',
                  1,
                  true,
                )
              }
              className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] disabled:bg-[#CBD5E1] disabled:cursor-not-allowed rounded-md transition-colors whitespace-nowrap cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              {product.stock === 0 ? 'Out of Stock' : 'Add to Bag'}
            </button>
            <button
              type="button"
              onClick={() => onSelect(product.id)}
              className="px-3 py-2 text-xs font-medium text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md transition-colors whitespace-nowrap cursor-pointer"
            >
              Details
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

import {
  ArrowLeft,
  Check,
  Heart,
  Ruler,
  ShieldCheck,
  ShoppingBag,
  Star,
  Truck,
  X,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type { Product, ProductSize } from '../types.ts';
import { discountPercent, formatINR } from '../utils/format.ts';
import { ProductCard } from './ProductCard.tsx';
import { ResilientImage } from './ResilientImage.tsx';

interface ProductDetailPageProps {
  productId: string;
  onBack: () => void;
  onSelectProduct: (productId: string) => void;
  onBuyNowCheckout: () => void;
}

export function ProductDetailPage({
  productId,
  onBack,
  onSelectProduct,
  onBuyNowCheckout,
}: ProductDetailPageProps) {
  const {
    products,
    addToCart,
    wishlistIds,
    toggleWishlist,
    user,
    token,
    setIsAuthModalOpen,
    refreshProducts,
    notify,
  } = useStore();

  const product = products.find((p) => p.id === productId || p.slug === productId);
  const [selectedSize, setSelectedSize] = useState<ProductSize>('M');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [activeImgIdx, setActiveImgIdx] = useState(0);
  const [pinCode, setPinCode] = useState('');
  const [pinResult, setPinResult] = useState<string | null>(null);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);

  // Review state
  const [ratingInput, setRatingInput] = useState(5);
  const [commentInput, setCommentInput] = useState('');
  const [cityInput, setCityInput] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    if (product) {
      setSelectedSize(product.sizes[0] || 'M');
      setSelectedColor(product.colors[0]?.name || 'Default');
      setActiveImgIdx(0);
      setPinResult(null);

      // SEO-friendly dynamic product page metadata
      document.title = `${product.name} — Vastra Atelier`;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute(
          'content',
          `${product.name} (${formatINR(product.price)}). ${product.description.slice(0, 120)}`,
        );
      }
    }
    return () => {
      document.title = 'Vastra Atelier — Contemporary Indian Luxury Fashion';
    };
  }, [product]);

  if (!product) {
    return (
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
        <h1 className="font-editorial text-3xl font-semibold text-[#111315]">
          Product not found
        </h1>
        <button
          type="button"
          onClick={onBack}
          className="mt-6 px-5 py-2.5 text-sm font-semibold text-white bg-[#111315] rounded-md"
        >
          Back to Catalog
        </button>
      </div>
    );
  }

  const isWishlisted = wishlistIds.includes(product.id);
  const pct = discountPercent(product.price, product.originalPrice);
  const related = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 3);

  const checkPinDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{6}$/.test(pinCode.trim())) {
      setPinResult('Please enter a valid 6-digit Indian PIN code.');
      return;
    }
    const metroPrefixes = ['11', '40', '56', '60', '70', '50', '38', '41'];
    const isMetro = metroPrefixes.some((p) => pinCode.startsWith(p));
    setPinResult(
      isMetro
        ? `Express delivery available to ${pinCode} in 2–3 business days. COD eligible.`
        : `Standard insured delivery to ${pinCode} in 4–6 business days. COD eligible.`,
    );
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !user) {
      setIsAuthModalOpen(true);
      return;
    }
    setSubmittingReview(true);
    try {
      const res = await fetch(`/api/products/${product.id}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          rating: ratingInput,
          comment: commentInput,
          city: cityInput,
        }),
      });
      const data = (await res.json()) as { product?: Product; error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not submit review.');
      setCommentInput('');
      setCityInput('');
      await refreshProducts();
      notify('Thank you—your review is now live.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Review submission failed.', 'error');
    } finally {
      setSubmittingReview(false);
    }
  };

  return (
    <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Structured JSON-LD for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Product',
            name: product.name,
            sku: product.sku,
            description: product.description,
            category: `${product.category} > ${product.subcategory}`,
            offers: {
              '@type': 'Offer',
              priceCurrency: 'INR',
              price: product.price,
              availability:
                product.stock > 0
                  ? 'https://schema.org/InStock'
                  : 'https://schema.org/OutOfStock',
            },
            aggregateRating:
              product.reviewCount > 0
                ? {
                    '@type': 'AggregateRating',
                    ratingValue: product.rating,
                    reviewCount: product.reviewCount,
                  }
                : undefined,
          }),
        }}
      />

      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-[#475569] hover:text-[#111315] mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Catalog
      </button>

      {/* Contiguous Purchase Module */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Sticky Image Gallery */}
        <div className="lg:col-span-7 lg:sticky lg:top-24 space-y-3">
          <div className="aspect-[4/3] bg-[#F1F3F5] border border-[#E2E8F0] rounded-lg overflow-hidden">
            <ResilientImage
              src={product.images[activeImgIdx] || product.images[0] || ''}
              alt={product.name}
              className="w-full h-full object-cover object-top"
            />
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-3">
              {product.images.map((img, idx) => (
                <button
                  key={`${img}-${idx}`}
                  type="button"
                  onClick={() => setActiveImgIdx(idx)}
                  className={`w-20 h-20 rounded-md overflow-hidden border-2 cursor-pointer ${
                    activeImgIdx === idx
                      ? 'border-[#111315]'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <ResilientImage
                    src={img}
                    alt={`${product.name} view ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Sticky Purchase Details */}
        <div className="lg:col-span-5 bg-white border border-[#E2E8F0] rounded-lg p-6 sm:p-8 space-y-6">
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-[#64748B]">
              {product.category} · {product.subcategory} · SKU {product.sku}
            </p>
            <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1.5">
              {product.name}
            </h1>

            <div className="flex items-center gap-3 mt-3">
              <div className="flex items-center gap-1 text-sm text-[#111315] tabular-nums">
                <Star className="w-4 h-4 fill-[#111315] text-[#111315]" />
                <span className="font-semibold">{product.rating.toFixed(1)}</span>
                <span className="text-[#64748B]">({product.reviewCount} reviews)</span>
              </div>
              <span className="text-[#CBD5E1]" aria-hidden="true">
                |
              </span>
              <span
                className={`text-xs font-semibold ${
                  product.stock > 0 ? 'text-[#166534]' : 'text-[#991B1B]'
                }`}
              >
                {product.stock > 10
                  ? 'In Stock — Ready to Dispatch'
                  : product.stock > 0
                    ? `Only ${product.stock} left in stock`
                    : 'Out of Stock'}
              </span>
            </div>
          </div>

          {/* Pricing */}
          <div className="pb-5 border-b border-[#E2E8F0]">
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-semibold text-[#111315] tabular-nums">
                {formatINR(product.price)}
              </span>
              {product.originalPrice > product.price && (
                <>
                  <span className="text-base text-[#94A3B8] line-through tabular-nums">
                    {formatINR(product.originalPrice)}
                  </span>
                  <span className="text-xs font-semibold text-[#1E2B48] uppercase tracking-wider">
                    Save {pct}%
                  </span>
                </>
              )}
            </div>
            <p className="text-xs text-[#64748B] mt-1">
              Inclusive of GST &amp; all duties
            </p>
          </div>

          <p className="text-sm leading-relaxed text-[#475569]">
            {product.description}
          </p>

          {/* Colour Selector */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#475569] mb-2.5">
              Colour: <span className="text-[#111315]">{selectedColor}</span>
            </p>
            <div className="flex flex-wrap gap-2.5">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  type="button"
                  onClick={() => setSelectedColor(c.name)}
                  aria-label={`Select colour ${c.name}`}
                  className={`inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                    selectedColor === c.name
                      ? 'border-[#111315] bg-[#F8F9FA] text-[#111315]'
                      : 'border-[#CBD5E1] text-[#475569] hover:border-[#111315]'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-black/15"
                    style={{ backgroundColor: c.hex }}
                  />
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          {/* Size Selector */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <p className="text-xs font-semibold uppercase tracking-wider text-[#475569]">
                Size: <span className="text-[#111315]">{selectedSize}</span>
              </p>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(true)}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#1E2B48] hover:underline cursor-pointer"
              >
                <Ruler className="w-3.5 h-3.5" />
                Size Guide
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setSelectedSize(sz)}
                  className={`min-w-[44px] px-3 py-2 text-xs font-semibold rounded-md border transition-colors cursor-pointer ${
                    selectedSize === sz
                      ? 'bg-[#111315] text-white border-[#111315]'
                      : 'bg-white text-[#111315] border-[#CBD5E1] hover:border-[#111315]'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Primary Action Buttons */}
          <div className="space-y-2.5 pt-2">
            <div className="flex gap-2.5">
              <button
                type="button"
                disabled={product.stock === 0}
                onClick={() =>
                  addToCart(product, selectedSize, selectedColor, 1, true)
                }
                className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] disabled:bg-[#CBD5E1] rounded-md transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                {product.stock === 0 ? 'Out of Stock' : 'Add to Bag'}
              </button>
              <button
                type="button"
                onClick={() => void toggleWishlist(product.id)}
                aria-label="Toggle wishlist"
                className="px-4 py-3 border border-[#CBD5E1] hover:border-[#111315] rounded-md transition-colors cursor-pointer"
              >
                <Heart
                  className={`w-4.5 h-4.5 ${
                    isWishlisted ? 'fill-[#1E2B48] text-[#1E2B48]' : 'text-[#111315]'
                  }`}
                />
              </button>
            </div>

            <button
              type="button"
              disabled={product.stock === 0}
              onClick={() => {
                addToCart(product, selectedSize, selectedColor, 1, false);
                onBuyNowCheckout();
              }}
              className="w-full py-3 px-4 text-sm font-semibold text-[#111315] bg-[#F1F3F5] hover:bg-[#E2E8F0] disabled:opacity-50 border border-[#CBD5E1] rounded-md transition-colors cursor-pointer"
            >
              Buy Now — Express Checkout
            </button>
          </div>

          {/* PIN Code Delivery Check */}
          <div className="pt-4 border-t border-[#E2E8F0]">
            <p className="text-xs font-semibold text-[#111315] flex items-center gap-1.5 mb-2">
              <Truck className="w-4 h-4 text-[#475569]" />
              Check Pan-India Delivery &amp; COD Availability
            </p>
            <form onSubmit={checkPinDelivery} className="flex gap-2">
              <input
                type="text"
                maxLength={6}
                value={pinCode}
                onChange={(e) => setPinCode(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter 6-digit PIN (e.g. 400001)"
                className="flex-1 px-3 py-2 text-xs border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315] tabular-nums"
              />
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md cursor-pointer"
              >
                Check
              </button>
            </form>
            {pinResult && (
              <p className="text-xs text-[#475569] mt-2 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-[#1E2B48] shrink-0" />
                {pinResult}
              </p>
            )}
          </div>

          {/* Fabric & Trust */}
          <div className="pt-4 border-t border-[#E2E8F0] space-y-2 text-xs text-[#475569]">
            <p>
              <strong className="text-[#111315]">Material &amp; Care:</strong>{' '}
              {product.fabricCare}
            </p>
            <p className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#1E2B48] shrink-0" />
              14-day complimentary size exchange &amp; pickup across India.
            </p>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <section className="mt-16 pt-12 border-t border-[#E2E8F0] grid grid-cols-1 lg:grid-cols-12 gap-10">
        <div className="lg:col-span-5">
          <h2 className="font-editorial text-3xl font-semibold text-[#111315]">
            Client Reviews ({product.reviewCount})
          </h2>
          <p className="text-sm text-[#64748B] mt-1">
            Rated {product.rating.toFixed(1)} out of 5 based on verified wearer feedback.
          </p>

          <form
            onSubmit={handleSubmitReview}
            className="mt-6 p-5 bg-white border border-[#E2E8F0] rounded-lg space-y-4"
          >
            <h3 className="text-sm font-semibold text-[#111315]">
              Write a Review
            </h3>
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1.5">
                Rating
              </label>
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRatingInput(star)}
                    aria-label={`Rate ${star} stars`}
                    className="p-1 cursor-pointer"
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= ratingInput
                          ? 'fill-[#111315] text-[#111315]'
                          : 'text-[#CBD5E1]'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                Your City (Optional)
              </label>
              <input
                type="text"
                value={cityInput}
                onChange={(e) => setCityInput(e.target.value)}
                placeholder="Mumbai"
                className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1">
                Review
              </label>
              <textarea
                rows={3}
                required
                value={commentInput}
                onChange={(e) => setCommentInput(e.target.value)}
                placeholder="Share notes on fabric, tailoring, or fit..."
                className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
              />
            </div>
            <button
              type="submit"
              disabled={submittingReview}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
            >
              {user
                ? submittingReview
                  ? 'Posting...'
                  : 'Submit Review'
                : 'Sign In to Review'}
            </button>
          </form>
        </div>

        <div className="lg:col-span-7 space-y-4">
          {product.reviews.length === 0 ? (
            <p className="text-sm text-[#64748B]">
              No reviews yet. Be the first to review this piece.
            </p>
          ) : (
            product.reviews.map((rev) => (
              <div
                key={rev.id}
                className="p-5 bg-white border border-[#E2E8F0] rounded-lg"
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-[#111315]">
                      {rev.userName}
                    </span>
                    {rev.city && (
                      <span className="text-xs text-[#64748B]">· {rev.city}</span>
                    )}
                    {rev.verified && (
                      <span className="text-[11px] font-medium text-[#1E2B48]">
                        · Verified Buyer
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-[#94A3B8] tabular-nums">
                    {rev.date}
                  </span>
                </div>
                <div className="flex items-center gap-0.5 mt-1.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-3.5 h-3.5 ${
                        s <= rev.rating
                          ? 'fill-[#111315] text-[#111315]'
                          : 'text-[#E2E8F0]'
                      }`}
                    />
                  ))}
                </div>
                <p className="text-sm text-[#475569] mt-2.5 leading-relaxed">
                  {rev.comment}
                </p>
              </div>
            ))
          )}
        </div>
      </section>

      {/* Related Products */}
      {related.length > 0 && (
        <section className="mt-16 pt-12 border-t border-[#E2E8F0]">
          <h2 className="font-editorial text-3xl font-semibold text-[#111315] mb-6">
            Complementary Pieces
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {related.map((item) => (
              <ProductCard
                key={item.id}
                product={item}
                onSelect={onSelectProduct}
              />
            ))}
          </div>
        </section>
      )}

      {/* Size Guide Modal */}
      {sizeGuideOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Indian Standard Size Guide"
        >
          <div className="bg-white max-w-lg w-full rounded-xl border border-[#E2E8F0] p-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
              <h3 className="font-editorial text-2xl font-semibold text-[#111315]">
                Garment Size Guide (Inches)
              </h3>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(false)}
                className="p-1 text-[#64748B] hover:text-[#111315] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse tabular-nums">
                <thead>
                  <tr className="border-b border-[#E2E8F0] text-[#64748B]">
                    <th className="py-2 pr-4">Size</th>
                    <th className="py-2 pr-4">Chest / Bust</th>
                    <th className="py-2 pr-4">Waist</th>
                    <th className="py-2">Shoulder</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#F1F5F9] text-[#111315]">
                  <tr><td className="py-2 pr-4 font-semibold">XS</td><td className="py-2 pr-4">36"</td><td className="py-2 pr-4">28"</td><td className="py-2">16.5"</td></tr>
                  <tr><td className="py-2 pr-4 font-semibold">S</td><td className="py-2 pr-4">38"</td><td className="py-2 pr-4">30"</td><td className="py-2">17.0"</td></tr>
                  <tr><td className="py-2 pr-4 font-semibold">M</td><td className="py-2 pr-4">40"</td><td className="py-2 pr-4">32"</td><td className="py-2">17.5"</td></tr>
                  <tr><td className="py-2 pr-4 font-semibold">L</td><td className="py-2 pr-4">42"</td><td className="py-2 pr-4">34"</td><td className="py-2">18.2"</td></tr>
                  <tr><td className="py-2 pr-4 font-semibold">XL</td><td className="py-2 pr-4">44"</td><td className="py-2 pr-4">36"</td><td className="py-2">19.0"</td></tr>
                  <tr><td className="py-2 pr-4 font-semibold">XXL</td><td className="py-2 pr-4">46"</td><td className="py-2 pr-4">38"</td><td className="py-2">19.5"</td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

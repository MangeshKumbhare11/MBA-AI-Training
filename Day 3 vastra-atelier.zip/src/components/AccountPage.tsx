import { LogOut, Package, Shield, User } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type { Order } from '../types.ts';
import { formatINR } from '../utils/format.ts';
import { ProductCard } from './ProductCard.tsx';
import { ResilientImage } from './ResilientImage.tsx';

interface AccountPageProps {
  initialTab?: 'orders' | 'wishlist' | 'profile';
  onSelectProduct: (id: string) => void;
  onOpenAdmin: () => void;
  onBrowseCatalog: () => void;
}

export function AccountPage({
  initialTab = 'orders',
  onSelectProduct,
  onOpenAdmin,
  onBrowseCatalog,
}: AccountPageProps) {
  const { user, token, logout, products, wishlistIds, setIsAuthModalOpen } =
    useStore();
  const [tab, setTab] = useState<'orders' | 'wishlist' | 'profile'>(initialTab);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);

  useEffect(() => {
    setTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (!token) return;
    setLoadingOrders(true);
    fetch('/api/orders/mine', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => (res.ok ? res.json() : { orders: [] }))
      .then((data: { orders: Order[] }) => setOrders(data.orders || []))
      .finally(() => setLoadingOrders(false));
  }, [token]);

  if (!user) {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center">
        <User className="w-10 h-10 text-[#64748B] mx-auto mb-3" />
        <h1 className="font-editorial text-3xl font-semibold text-[#111315]">
          Sign in to view your account
        </h1>
        <p className="text-sm text-[#64748B] mt-2">
          Track orders, manage saved wishlist items, and enjoy faster checkout.
        </p>
        <button
          type="button"
          onClick={() => setIsAuthModalOpen(true)}
          className="mt-6 px-6 py-3 text-sm font-semibold text-white bg-[#111315] rounded-md cursor-pointer"
        >
          Sign In / Register
        </button>
      </div>
    );
  }

  const wishlistedProducts = products.filter((p) => wishlistIds.includes(p.id));

  return (
    <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E2E8F0]">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
            Member Account
          </p>
          <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
            Welcome, {user.name}
          </h1>
        </div>

        <div className="flex items-center gap-3">
          {user.role === 'admin' && (
            <button
              type="button"
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#1E2B48] hover:bg-[#111315] rounded-md cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5" />
              Open Admin Dashboard
            </button>
          )}
          <button
            type="button"
            onClick={logout}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-6 flex items-center gap-2 border-b border-[#E2E8F0]">
        {[
          { id: 'orders' as const, label: `Order History (${orders.length})` },
          { id: 'wishlist' as const, label: `Saved Wishlist (${wishlistedProducts.length})` },
          { id: 'profile' as const, label: 'Profile Details' },
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
              tab === t.id
                ? 'border-[#111315] text-[#111315]'
                : 'border-transparent text-[#64748B] hover:text-[#111315]'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Order History */}
      {tab === 'orders' && (
        <div className="mt-8 space-y-4">
          {loadingOrders ? (
            <div className="h-40 bg-[#F1F3F5] rounded-lg animate-pulse" />
          ) : orders.length === 0 ? (
            <div className="p-10 bg-white border border-[#E2E8F0] rounded-lg text-center">
              <Package className="w-8 h-8 text-[#94A3B8] mx-auto mb-2" />
              <p className="text-sm font-semibold text-[#111315]">
                No orders placed yet
              </p>
              <button
                type="button"
                onClick={onBrowseCatalog}
                className="mt-4 px-5 py-2 text-xs font-semibold text-white bg-[#111315] rounded-md cursor-pointer"
              >
                Start Shopping
              </button>
            </div>
          ) : (
            orders.map((order) => (
              <div
                key={order.id}
                className="bg-white border border-[#E2E8F0] rounded-lg p-6 space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#F1F5F9]">
                  <div>
                    <p className="font-mono text-sm font-semibold text-[#111315]">
                      {order.id}
                    </p>
                    <p className="text-xs text-[#64748B] mt-0.5">
                      Placed on {new Date(order.createdAt).toLocaleDateString('en-IN')} ·{' '}
                      {order.paymentMethod} ({order.paymentStatus})
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-semibold uppercase tracking-wider text-[#1E2B48]">
                      Status: {order.status}
                    </span>
                    <p className="text-base font-semibold text-[#111315] tabular-nums mt-0.5">
                      {formatINR(order.total)}
                    </p>
                  </div>
                </div>

                <div className="divide-y divide-[#F1F5F9]">
                  {order.items.map((item, idx) => (
                    <div
                      key={idx}
                      className="py-3 flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-14 h-14 rounded bg-[#F1F3F5] overflow-hidden shrink-0">
                          <ResilientImage
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#111315] truncate">
                            {item.name}
                          </p>
                          <p className="text-xs text-[#64748B]">
                            Size: {item.size} · {item.color} · Qty {item.quantity}
                          </p>
                        </div>
                      </div>
                      <span className="text-sm font-medium text-[#111315] tabular-nums">
                        {formatINR(item.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="text-xs text-[#64748B] pt-2 border-t border-[#F1F5F9]">
                  Shipping to: {order.shippingAddress.fullName},{' '}
                  {order.shippingAddress.street}, {order.shippingAddress.city},{' '}
                  {order.shippingAddress.state} - {order.shippingAddress.pinCode}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Wishlist */}
      {tab === 'wishlist' && (
        <div className="mt-8">
          {wishlistedProducts.length === 0 ? (
            <div className="p-10 bg-white border border-[#E2E8F0] rounded-lg text-center">
              <p className="text-sm font-semibold text-[#111315]">
                Your wishlist is currently empty
              </p>
              <button
                type="button"
                onClick={onBrowseCatalog}
                className="mt-4 px-5 py-2 text-xs font-semibold text-white bg-[#111315] rounded-md cursor-pointer"
              >
                Explore Collection
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {wishlistedProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  product={p}
                  onSelect={onSelectProduct}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Profile */}
      {tab === 'profile' && (
        <div className="mt-8 max-w-xl bg-white border border-[#E2E8F0] rounded-lg p-6 space-y-3 text-sm">
          <div className="flex justify-between py-2 border-b border-[#F1F5F9]">
            <span className="text-[#64748B]">Full Name</span>
            <span className="font-medium text-[#111315]">{user.name}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-[#F1F5F9]">
            <span className="text-[#64748B]">Email</span>
            <span className="font-medium text-[#111315]">{user.email}</span>
          </div>
          <div className="flex justify-between py-2 border-b border-[#F1F5F9]">
            <span className="text-[#64748B]">Mobile</span>
            <span className="font-medium text-[#111315] tabular-nums">{user.phone}</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-[#64748B]">Account Role</span>
            <span className="font-medium text-[#111315] capitalize">{user.role}</span>
          </div>
        </div>
      )}
    </div>
  );
}

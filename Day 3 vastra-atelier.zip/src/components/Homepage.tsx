import { ArrowRight, Check, Copy, Instagram, Star } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type { CollectionTag, MainCategory } from '../types.ts';
import type { AppRoute } from './Header.tsx';
import { ProductCard } from './ProductCard.tsx';
import { ResilientImage } from './ResilientImage.tsx';

interface HomepageProps {
  onNavigate: (route: AppRoute) => void;
}

const COLLECTION_TABS: CollectionTag[] = [
  'New Arrivals',
  'Trending',
  'Best Sellers',
  'Featured',
];

const LOOKBOOK_TILES = [
  {
    image: '/src/assets/images/mens_kurta_jacket_1795244907561.jpg',
    title: 'Midnight Matka Silk Bandi',
    handle: '@vastra.atelier · Mumbai',
    productId: 'prod-nawab-nehru-set',
  },
  {
    image: '/src/assets/images/womens_banarasi_saree_1795244907898.jpg',
    title: 'Varanasi Katan Silk Drape',
    handle: '@vastra.atelier · Varanasi',
    productId: 'prod-banarasi-saree',
  },
  {
    image: '/src/assets/images/womens_chanderi_kurti_1795244907739.jpg',
    title: 'Mist Chanderi Straight Kurti',
    handle: '@vastra.atelier · Jaipur',
    productId: 'prod-chanderi-kurti',
  },
  {
    image: '/src/assets/images/mens_linen_shirt_1795244909118.jpg',
    title: 'Alibaug Mandarin Linen',
    handle: '@vastra.atelier · Alibaug',
    productId: 'prod-alibaug-linen',
  },
  {
    image: '/src/assets/images/womens_evening_dress_1795244910895.jpg',
    title: 'Colaba Poplin Midi Dress',
    handle: '@vastra.atelier · South Bombay',
    productId: 'prod-colaba-dress',
  },
  {
    image: '/src/assets/images/acc_chronograph_watch_1795244907741.jpg',
    title: 'Sovereign 316L Chronograph',
    handle: '@vastra.atelier · Bengaluru',
    productId: 'prod-sovereign-watch',
  },
];

const TESTIMONIALS = [
  {
    name: 'Vikramaditya Rao',
    city: 'Bengaluru · Verified Buyer',
    item: 'Alibaug Mandarin Linen Shirt',
    quote:
      'Switched from heavy formal shirts to Vastra’s pure linen for studio days. The collar stays crisp through Bengaluru humidity without feeling stiff.',
  },
  {
    name: 'Nandini Kulkarni',
    city: 'Pune · Verified Buyer',
    item: 'Varanasi Midnight Banarasi Saree',
    quote:
      'Ordered for a family wedding reception. The silver-tested zari weave feels genuinely handloom and arrived neatly pressed in a muslin garment wrap.',
  },
  {
    name: 'Rohan Malhotra',
    city: 'New Delhi · Verified Buyer',
    item: 'Kora Heavyweight Supima Tee',
    quote:
      'After five washes the neckline hasn’t relaxed a millimetre. Worth every rupee compared to fast-fashion basics.',
  },
];

export function Homepage({ onNavigate }: HomepageProps) {
  const { products, productsLoading, notify } = useStore();
  const [activeCollection, setActiveCollection] =
    useState<CollectionTag>('New Arrivals');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterDone, setNewsletterDone] = useState(false);
  const [newsletterLoading, setNewsletterLoading] = useState(false);

  const displayedProducts = products
    .filter((p) => p.collections.includes(activeCollection))
    .slice(0, 4);

  const handleCopyCoupon = (code: string) => {
    void navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    notify(`Coupon ${code} copied to clipboard.`, 'success');
    window.setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleNewsletter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setNewsletterLoading(true);
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail }),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not subscribe.');
      setNewsletterDone(true);
      setNewsletterEmail('');
      notify('Subscribed to Vastra Atelier dispatches.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Subscription failed.', 'error');
    } finally {
      setNewsletterLoading(false);
    }
  };

  const categoryCards: {
    category: MainCategory;
    subtitle: string;
    image: string;
    subLinks: string[];
  }[] = [
    {
      category: "Men's Fashion",
      subtitle: 'Tailored linen, Supima essentials & ceremonial bandis',
      image: '/src/assets/images/mens_linen_shirt_1795244909118.jpg',
      subLinks: ['T-shirts', 'Shirts', 'Jeans', 'Trousers', 'Jackets', 'Ethnic Wear'],
    },
    {
      category: "Women's Fashion",
      subtitle: 'Handloom Banarasi sarees, Chanderi kurtis & structured dresses',
      image: '/src/assets/images/womens_chanderi_kurti_1795244907739.jpg',
      subLinks: ['Kurtis', 'Dresses', 'Tops', 'Sarees', 'Jeans', 'Ethnic Wear'],
    },
    {
      category: 'Accessories',
      subtitle: '316L steel chronographs, full-grain totes & bridle belts',
      image: '/src/assets/images/acc_leather_tote_belt_1795244908804.jpg',
      subLinks: ['Watches', 'Bags', 'Belts', 'Fashion Accessories'],
    },
  ];

  return (
    <div>
      {/* 1. Hero Campaign Split */}
      <section className="bg-white border-b border-[#E2E8F0]">
        <div className="max-w-[1320px] mx-auto grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-5 px-6 sm:px-10 lg:px-12 py-12 lg:py-20 flex flex-col justify-center">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#1E2B48] mb-4">
              Autumn · Festive Atelier Edit 2026
            </p>
            <h1 className="font-editorial text-[clamp(2.25rem,4vw,3.75rem)] leading-[1.06] font-semibold text-[#111315] text-balance">
              Upgrade Your Style. Define Your Identity.
            </h1>
            <p className="mt-5 text-[15px] leading-relaxed text-[#475569] max-w-md">
              Contemporary Indian menswear, handloom womenswear, and architectural
              accessories crafted from breathable Supima cotton, Belgian linen, and
              Katan silk.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onNavigate({ view: 'catalog', category: 'All' })}
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md transition-colors whitespace-nowrap cursor-pointer"
              >
                Shop Now
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() =>
                  onNavigate({
                    view: 'catalog',
                    category: 'All',
                    collection: 'New Arrivals',
                  })
                }
                className="inline-flex items-center px-5 py-3 text-sm font-medium text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md transition-colors whitespace-nowrap cursor-pointer"
              >
                New Arrivals
              </button>
            </div>

            <div className="mt-10 pt-6 border-t border-[#E2E8F0] grid grid-cols-3 gap-4 text-left">
              <div>
                <p className="text-sm font-semibold text-[#111315] tabular-nums">
                  100%
                </p>
                <p className="text-xs text-[#64748B] mt-0.5">Natural Weaves</p>
              </div>
              <div>
                <p className="text-sm font-semibold text-[#111315] tabular-nums">
                  28,000+
                </p>
                <p className="text-xs text-[#64748B] mt-0.5">PIN Codes Served</p>
              </div>
              <div>
                <p className="text-sm font-semibold text-[#111315] tabular-nums">
                  14-Day
                </p>
                <p className="text-xs text-[#64748B] mt-0.5">Hassle-Free Returns</p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 relative min-h-[340px] lg:min-h-[560px] bg-[#F1F3F5]">
            <ResilientImage
              src="/src/assets/images/hero_fashion_models_1795244904362.jpg"
              alt="Contemporary Indian fashion models in tailored blazer and draped silk ensemble"
              className="w-full h-full lg:h-full object-cover object-center"
            />
            <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-black/70 via-black/30 to-transparent flex items-end p-6 sm:p-8">
              <div className="flex flex-wrap items-center justify-between gap-4 w-full text-white">
                <p className="text-xs sm:text-sm font-medium tracking-wide">
                  Studio Mumbai · Tailored Wool-Linen Blazer &amp; Draped Silk Edit
                </p>
                <button
                  type="button"
                  onClick={() =>
                    onNavigate({ view: 'product', productId: 'prod-nawab-nehru-set' })
                  }
                  className="text-xs font-semibold underline underline-offset-4 hover:text-white/80 whitespace-nowrap cursor-pointer"
                >
                  View Look
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Shop by Department (Men, Women, Accessories) */}
      <section className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
              Departments
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
              Tailored Wardrobes for Every Occasion
            </h2>
          </div>
          <button
            type="button"
            onClick={() => onNavigate({ view: 'catalog', category: 'All' })}
            className="text-sm font-medium text-[#111315] hover:text-[#1E2B48] inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            Browse Full Catalog
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categoryCards.map((dept) => (
            <div
              key={dept.category}
              className="bg-white border border-[#E2E8F0] rounded-lg overflow-hidden flex flex-col"
            >
              <button
                type="button"
                onClick={() =>
                  onNavigate({ view: 'catalog', category: dept.category })
                }
                className="aspect-[4/3] bg-[#F1F3F5] overflow-hidden block text-left cursor-pointer group"
              >
                <ResilientImage
                  src={dept.image}
                  alt={dept.category}
                  className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.03]"
                />
              </button>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate({ view: 'catalog', category: dept.category })
                    }
                    className="font-editorial text-2xl font-semibold text-[#111315] hover:text-[#1E2B48] cursor-pointer"
                  >
                    {dept.category}
                  </button>
                  <p className="text-sm text-[#475569] mt-1">{dept.subtitle}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F1F5F9] flex flex-wrap gap-x-3 gap-y-1.5">
                  {dept.subLinks.map((sub) => (
                    <button
                      key={sub}
                      type="button"
                      onClick={() =>
                        onNavigate({
                          view: 'catalog',
                          category: dept.category,
                          subcategory: sub,
                        })
                      }
                      className="text-xs font-medium text-[#475569] hover:text-[#111315] hover:underline underline-offset-4 cursor-pointer"
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Curated Collections Tabs (New Arrivals / Trending / Best Sellers / Featured) */}
      <section className="bg-white border-y border-[#E2E8F0] py-14 sm:py-16">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
                Curated Edit
              </p>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
                {activeCollection}
              </h2>
            </div>

            <div
              role="tablist"
              aria-label="Collection filters"
              className="inline-flex flex-wrap items-center gap-1 p-1 bg-[#F1F3F5] rounded-lg border border-[#E2E8F0]"
            >
              {COLLECTION_TABS.map((tab) => (
                <button
                  key={tab}
                  type="button"
                  role="tab"
                  aria-selected={activeCollection === tab}
                  onClick={() => setActiveCollection(tab)}
                  className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    activeCollection === tab
                      ? 'bg-white text-[#111315] shadow-xs'
                      : 'text-[#475569] hover:text-[#111315]'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          {productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="h-96 bg-[#F1F3F5] rounded-lg animate-pulse"
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {displayedProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelect={(id) => onNavigate({ view: 'product', productId: id })}
                />
              ))}
            </div>
          )}

          <div className="mt-10 text-center">
            <button
              type="button"
              onClick={() =>
                onNavigate({
                  view: 'catalog',
                  category: 'All',
                  collection: activeCollection,
                })
              }
              className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-[#111315] border border-[#111315] hover:bg-[#111315] hover:text-white rounded-md transition-colors cursor-pointer"
            >
              View All {activeCollection}
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* 4. Special Offers & Privilege Codes */}
      <section className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-14 sm:py-16">
        <div className="bg-[#111315] text-white rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-center">
            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#CBD5E1]">
              Limited-Time Seasonal Privileges
            </p>
            <h2 className="font-editorial text-3xl sm:text-4xl font-semibold mt-2 text-balance">
              Complimentary Tailoring Value on Your Wardrobe Upgrade
            </h2>
            <p className="text-sm text-[#CBD5E1] mt-3 max-w-xl leading-relaxed">
              Apply any privilege code at checkout for instant savings across
              menswear, womenswear, ethnic couture, and accessories.
            </p>

            <div className="mt-7 grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { code: 'WELCOME15', desc: '15% off first order' },
                { code: 'VASTRA20', desc: '20% off ₹6,000+' },
                { code: 'FESTIVE1000', desc: 'Flat ₹1,000 off ₹4,999+' },
              ].map((offer) => (
                <button
                  key={offer.code}
                  type="button"
                  onClick={() => handleCopyCoupon(offer.code)}
                  className="text-left p-3.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs font-semibold tracking-wider text-white">
                      {offer.code}
                    </span>
                    {copiedCode === offer.code ? (
                      <Check className="w-3.5 h-3.5 text-white" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-[#CBD5E1]" />
                    )}
                  </div>
                  <p className="text-xs text-[#CBD5E1] mt-1">{offer.desc}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-5 relative min-h-[260px] bg-[#1E2B48]">
            <ResilientImage
              src="/src/assets/images/womens_banarasi_saree_1795244907898.jpg"
              alt="Festive silk collection showcase"
              className="w-full h-full object-cover object-top"
            />
          </div>
        </div>
      </section>

      {/* 5. Verified Customer Reviews & Instagram Lookbook */}
      <section className="bg-white border-t border-[#E2E8F0] py-14 sm:py-16">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
          {/* Customer Testimonials */}
          <div>
            <div className="mb-8">
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
                Client Notes
              </p>
              <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
                Worn Across India
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {TESTIMONIALS.map((t) => (
                <blockquote
                  key={t.name}
                  className="p-6 bg-[#F8F9FA] border border-[#E2E8F0] rounded-lg flex flex-col justify-between gap-5"
                >
                  <div>
                    <div className="flex items-center gap-1 mb-3">
                      {[0, 1, 2, 3, 4].map((star) => (
                        <Star
                          key={star}
                          className="w-3.5 h-3.5 fill-[#111315] text-[#111315]"
                        />
                      ))}
                    </div>
                    <p className="text-sm leading-relaxed text-[#111315]">
                      “{t.quote}”
                    </p>
                  </div>
                  <footer className="pt-3 border-t border-[#E2E8F0]">
                    <p className="text-sm font-semibold text-[#111315]">{t.name}</p>
                    <p className="text-xs text-[#64748B] mt-0.5">
                      {t.city} · {t.item}
                    </p>
                  </footer>
                </blockquote>
              ))}
            </div>
          </div>

          {/* Instagram-Style Lookbook Gallery */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
                  @vastra.atelier
                </p>
                <h2 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
                  Styled Lookbook Gallery
                </h2>
              </div>
              <a
                href="#newsletter"
                className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#111315] hover:text-[#1E2B48]"
              >
                <Instagram className="w-4 h-4" />
                Click any look to shop
              </a>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {LOOKBOOK_TILES.map((tile) => (
                <button
                  key={tile.title}
                  type="button"
                  onClick={() =>
                    onNavigate({ view: 'product', productId: tile.productId })
                  }
                  className="group relative aspect-square rounded-lg overflow-hidden bg-[#F1F3F5] border border-[#E2E8F0] text-left cursor-pointer"
                >
                  <ResilientImage
                    src={tile.image}
                    alt={tile.title}
                    className="w-full h-full object-cover object-top transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col justify-end p-3">
                    <p className="text-xs font-semibold text-white line-clamp-1">
                      {tile.title}
                    </p>
                    <p className="text-[11px] text-white/80 mt-0.5">Shop Look</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Newsletter Subscription */}
          <div
            id="newsletter"
            className="bg-[#F8F9FA] border border-[#E2E8F0] rounded-xl p-8 sm:p-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6"
          >
            <div className="max-w-lg">
              <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
                The Atelier Dispatch
              </p>
              <h3 className="font-editorial text-2xl sm:text-3xl font-semibold text-[#111315] mt-1">
                Private Previews &amp; Limited Handloom Drops
              </h3>
              <p className="text-sm text-[#475569] mt-1.5">
                Receive early access to seasonal collections, textile stories, and
                subscriber-only privilege codes.
              </p>
            </div>

            {newsletterDone ? (
              <div className="px-5 py-3 bg-white border border-[#CBD5E1] rounded-md text-sm font-medium text-[#111315]">
                Thank you for joining the Vastra Atelier list.
              </div>
            ) : (
              <form
                onSubmit={handleNewsletter}
                className="flex flex-col sm:flex-row gap-2.5 w-full lg:w-auto lg:min-w-[420px]"
              >
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="Enter your email address"
                  className="flex-1 px-4 py-3 text-sm bg-white border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315]"
                />
                <button
                  type="submit"
                  disabled={newsletterLoading}
                  className="px-6 py-3 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] disabled:opacity-60 rounded-md transition-colors whitespace-nowrap cursor-pointer"
                >
                  {newsletterLoading ? 'Joining...' : 'Subscribe'}
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

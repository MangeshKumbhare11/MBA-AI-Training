import { Check, Copy, MessageCircle, Send, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';

export function WhatsAppConcierge() {
  const { notify } = useStore();
  const [open, setOpen] = useState(false);
  const [inquiry, setInquiry] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiry.trim()) return;
    notify(
      'Stylist request logged. Our Mumbai atelier concierge responds within 15 minutes on WhatsApp.',
      'success',
    );
    setInquiry('');
    setOpen(false);
  };

  return (
    <div className="fixed bottom-5 right-5 z-40">
      {open && (
        <div className="mb-3 w-80 bg-white border border-[#E2E8F0] rounded-xl shadow-2xl overflow-hidden">
          <div className="bg-[#111315] text-white px-4 py-3 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">WhatsApp Style Concierge</p>
              <p className="text-[11px] text-white/75">
                Sizing, custom tailoring &amp; order help
              </p>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close WhatsApp concierge"
              className="p-1 text-white/75 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <form onSubmit={handleSend} className="p-4 space-y-3">
            <textarea
              rows={3}
              required
              value={inquiry}
              onChange={(e) => setInquiry(e.target.value)}
              placeholder="Ask about fabric weight, size fit, or wedding styling..."
              className="w-full px-3 py-2 text-xs border border-[#CBD5E1] rounded-md"
            />
            <div className="flex items-center justify-between gap-2">
              <a
                href={`https://wa.me/919820011223?text=${encodeURIComponent(
                  inquiry || 'Hello Vastra Atelier, I need styling assistance.',
                )}`}
                target="_blank"
                rel="noreferrer"
                className="text-xs font-medium text-[#1E2B48] hover:underline"
              >
                Open in WhatsApp Web
              </a>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                Send
              </button>
            </div>
          </form>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="WhatsApp Fashion Concierge"
        className="inline-flex items-center gap-2 px-4 py-3 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-full shadow-lg transition-transform hover:-translate-y-0.5 cursor-pointer"
      >
        <MessageCircle className="w-4 h-4" />
        <span className="hidden sm:inline">WhatsApp Concierge</span>
      </button>
    </div>
  );
}

export function FirstOrderPopup() {
  const { notify } = useStore();
  const [visible, setVisible] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem('vastra_first_order_seen')) return;

    let scrolled = false;
    let dwelled = false;

    const tryOpen = () => {
      if (scrolled && dwelled && !sessionStorage.getItem('vastra_first_order_seen')) {
        sessionStorage.setItem('vastra_first_order_seen', '1');
        setVisible(true);
      }
    };

    const onScroll = () => {
      if (window.scrollY > 360) {
        scrolled = true;
        tryOpen();
      }
    };

    const timer = window.setTimeout(() => {
      dwelled = true;
      tryOpen();
    }, 12000);

    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  if (!visible) return null;

  const copyCode = () => {
    void navigator.clipboard?.writeText('WELCOME15');
    setCopied(true);
    notify('First-order code WELCOME15 copied.', 'success');
    window.setTimeout(() => setVisible(false), 1100);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="First order privilege offer"
    >
      <div className="bg-white max-w-md w-full rounded-xl border border-[#E2E8F0] p-7 relative shadow-2xl">
        <button
          type="button"
          onClick={() => setVisible(false)}
          aria-label="Close offer"
          className="absolute top-4 right-4 p-1.5 text-[#64748B] hover:text-[#111315] cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#1E2B48]">
          First Order Privilege
        </p>
        <h3 className="font-editorial text-3xl font-semibold text-[#111315] mt-1.5">
          Enjoy 15% Off Your First Wardrobe Piece
        </h3>
        <p className="text-sm text-[#475569] mt-2 leading-relaxed">
          Apply privilege code <span className="font-mono font-semibold text-[#111315]">WELCOME15</span> at checkout for up to ₹2,000 savings on orders above ₹1,499.
        </p>

        <div className="mt-5 flex items-center gap-2">
          <button
            type="button"
            onClick={copyCode}
            className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Code Copied' : 'Copy Code WELCOME15'}
          </button>
        </div>
      </div>
    </div>
  );
}

import { Instagram, Mail, MapPin, Phone } from 'lucide-react';
import type { AppRoute } from './Header.tsx';

interface FooterProps {
  onNavigate: (route: AppRoute) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-[#111315] text-[#E2E8F0] border-t border-[#27272A]">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-14 grid grid-cols-1 md:grid-cols-12 gap-10">
        <div className="md:col-span-4 space-y-3">
          <p className="font-editorial text-2xl font-semibold text-white">
            Vastra Atelier
          </p>
          <p className="text-sm text-[#94A3B8] leading-relaxed max-w-sm">
            Upgrade Your Style. Define Your Identity. Contemporary Indian luxury
            menswear, handloom womenswear, and artisanal leather accessories
            shipped across India.
          </p>
          <div className="pt-2 space-y-1.5 text-xs text-[#94A3B8]">
            <p className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 shrink-0" />
              Kala Ghoda Flagship, Fort, Mumbai 400001
            </p>
            <p className="flex items-center gap-2 tabular-nums">
              <Phone className="w-3.5 h-3.5 shrink-0" />
              +91 22 4890 2210 (Mon–Sat, 10 AM – 7 PM IST)
            </p>
            <p className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 shrink-0" />
              concierge@vastraatelier.in
            </p>
          </div>
        </div>

        <div className="md:col-span-2 space-y-2.5">
          <p className="text-xs font-semibold uppercase tracking-wider text-white">
            Shop
          </p>
          <ul className="space-y-2 text-xs text-[#94A3B8]">
            <li>
              <button
                type="button"
                onClick={() =>
                  onNavigate({ view: 'catalog', category: "Men's Fashion" })
                }
                className="hover:text-white cursor-pointer"
              >
                Men&apos;s Fashion
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() =>
                  onNavigate({ view: 'catalog', category: "Women's Fashion" })
                }
                className="hover:text-white cursor-pointer"
              >
                Women&apos;s Fashion
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() =>
                  onNavigate({ view: 'catalog', category: 'Accessories' })
                }
                className="hover:text-white cursor-pointer"
              >
                Watches &amp; Leather
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() =>
                  onNavigate({
                    view: 'catalog',
                    category: 'All',
                    collection: 'New Arrivals',
                  })
                }
                className="hover:text-white cursor-pointer"
              >
                New Arrivals
              </button>
            </li>
          </ul>
        </div>

        <div className="md:col-span-3 space-y-2.5">
          <p className="text-xs font-semibold uppercase tracking-wider text-white">
            Client Services
          </p>
          <ul className="space-y-2 text-xs text-[#94A3B8]">
            <li>
              <button
                type="button"
                onClick={() => onNavigate({ view: 'account', tab: 'orders' })}
                className="hover:text-white cursor-pointer"
              >
                Order Tracking &amp; History
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() => onNavigate({ view: 'account', tab: 'wishlist' })}
                className="hover:text-white cursor-pointer"
              >
                Saved Wishlist
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() => onNavigate({ view: 'checkout' })}
                className="hover:text-white cursor-pointer"
              >
                Express Checkout
              </button>
            </li>
            <li>
              <button
                type="button"
                onClick={() => onNavigate({ view: 'admin' })}
                className="hover:text-white cursor-pointer"
              >
                Merchant Admin Portal
              </button>
            </li>
          </ul>
        </div>

        <div className="md:col-span-3 space-y-2.5">
          <p className="text-xs font-semibold uppercase tracking-wider text-white">
            Payments &amp; Social
          </p>
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Secured by Razorpay Test Gateway: UPI (GPay, PhonePe, Paytm),
            Credit &amp; Debit Cards, Net Banking, and Cash on Delivery across
            28,000+ Indian PIN codes.
          </p>
          <div className="pt-2 flex items-center gap-4 text-xs text-[#CBD5E1]">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 hover:text-white"
            >
              <Instagram className="w-4 h-4" />
              Instagram
            </a>
            <a
              href="https://pinterest.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white"
            >
              Pinterest
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white"
            >
              YouTube
            </a>
          </div>
        </div>
      </div>

      <div className="border-t border-[#27272A]">
        <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#94A3B8]">
          <p>© {new Date().getFullYear()} Vastra Atelier Pvt. Ltd. All rights reserved.</p>
          <p>Pan-India Express Delivery · 14-Day Complimentary Exchanges</p>
        </div>
      </div>
    </footer>
  );
}

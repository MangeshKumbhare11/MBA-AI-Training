import { Building2, CreditCard, Lock, Smartphone, X } from 'lucide-react';
import { useState } from 'react';
import type { PaymentMethod } from '../types.ts';
import { formatINR } from '../utils/format.ts';

interface RazorpayModalProps {
  open: boolean;
  amount: number;
  razorpayOrderId: string;
  initialMethod: Exclude<PaymentMethod, 'COD'>;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  onCancel: () => void;
  onSuccess: (paymentId: string) => void;
}

export function RazorpayModal({
  open,
  amount,
  razorpayOrderId,
  initialMethod,
  customerName,
  customerEmail,
  customerPhone,
  onCancel,
  onSuccess,
}: RazorpayModalProps) {
  const [method, setMethod] = useState<Exclude<PaymentMethod, 'COD'>>(initialMethod);
  const [upiId, setUpiId] = useState('success@razorpay');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [processing, setProcessing] = useState(false);

  if (!open) return null;

  const handlePayTest = (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);
    window.setTimeout(() => {
      const testPayId = `pay_test_${Math.random().toString(36).slice(2, 10)}`;
      setProcessing(false);
      onSuccess(testPayId);
    }, 900);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Razorpay Test Mode Gateway"
    >
      <div className="bg-white w-full max-w-md rounded-xl overflow-hidden shadow-2xl border border-[#E2E8F0]">
        {/* Gateway Top Bar */}
        <div className="bg-[#1E2B48] text-white px-6 py-4 flex items-center justify-between">
          <div>
            <p className="text-xs uppercase tracking-widest text-white/75">
              Razorpay · Test Mode
            </p>
            <p className="text-base font-semibold mt-0.5">Vastra Atelier</p>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold tabular-nums">
              {formatINR(amount)}
            </p>
            <button
              type="button"
              onClick={onCancel}
              aria-label="Cancel payment"
              className="text-xs text-white/80 hover:text-white underline cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>

        <form onSubmit={handlePayTest} className="p-6 space-y-5">
          <div className="text-xs text-[#64748B] flex items-center justify-between bg-[#F8F9FA] px-3 py-2 rounded border border-[#E2E8F0]">
            <span className="truncate">
              {customerName} · {customerPhone}
            </span>
            <span className="font-mono text-[11px]">{razorpayOrderId}</span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'UPI' as const, label: 'UPI', icon: Smartphone },
              { id: 'CARD' as const, label: 'Cards', icon: CreditCard },
              { id: 'NETBANKING' as const, label: 'NetBanking', icon: Building2 },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setMethod(tab.id)}
                  className={`flex flex-col items-center justify-center gap-1 py-2.5 px-2 rounded-md border text-xs font-semibold transition-colors cursor-pointer ${
                    method === tab.id
                      ? 'border-[#1E2B48] bg-[#F1F5F9] text-[#111315]'
                      : 'border-[#E2E8F0] text-[#64748B] hover:border-[#94A3B8]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {method === 'UPI' && (
            <div className="space-y-3">
              <label className="block text-xs font-medium text-[#475569]">
                Enter Test UPI ID (GPay, PhonePe, Paytm)
              </label>
              <input
                type="text"
                required
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="yourname@okaxis"
                className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md font-mono"
              />
              <p className="text-[11px] text-[#64748B]">
                Sandbox default: <span className="font-mono">success@razorpay</span>
              </p>
            </div>
          )}

          {method === 'CARD' && (
            <div className="space-y-3">
              <p className="text-xs text-[#475569] bg-[#F8F9FA] p-3 rounded border border-[#E2E8F0]">
                Test Mode simulated card authorization. No real card numbers are
                collected or stored by Vastra Atelier.
              </p>
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  Test Card Token
                </label>
                <input
                  type="text"
                  readOnly
                  value="VISA ···· ···· ···· 1111 (Test Mode)"
                  className="w-full px-3 py-2 text-sm bg-[#F8F9FA] border border-[#CBD5E1] rounded-md font-mono text-[#475569]"
                />
              </div>
            </div>
          )}

          {method === 'NETBANKING' && (
            <div className="space-y-2">
              <label className="block text-xs font-medium text-[#475569]">
                Select Indian Bank (Test Mode)
              </label>
              <select
                value={selectedBank}
                onChange={(e) => setSelectedBank(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
              >
                <option>HDFC Bank</option>
                <option>ICICI Bank</option>
                <option>State Bank of India</option>
                <option>Axis Bank</option>
                <option>Kotak Mahindra Bank</option>
              </select>
            </div>
          )}

          <div className="pt-2 space-y-2">
            <button
              type="submit"
              disabled={processing}
              className="w-full py-3 px-4 text-sm font-semibold text-white bg-[#1E2B48] hover:bg-[#111315] disabled:opacity-60 rounded-md transition-colors cursor-pointer"
            >
              {processing
                ? 'Authorizing Test Payment...'
                : `Pay ${formatINR(amount)} (Test Mode)`}
            </button>
            <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#64748B]">
              <Lock className="w-3 h-3" />
              <span>256-bit Encrypted Razorpay Integration · {customerEmail}</span>
            </div>
          </div>
        </form>
        <button
          type="button"
          onClick={onCancel}
          aria-label="Close payment window"
          className="hidden"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

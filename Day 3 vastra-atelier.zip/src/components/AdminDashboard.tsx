import {
  BarChart3,
  Edit3,
  Minus,
  Package,
  Plus,
  ShieldAlert,
  ShoppingBag,
  Trash2,
  Upload,
  Users,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type {
  AdminStats,
  CollectionTag,
  CustomerSummary,
  MainCategory,
  Order,
  OrderStatus,
  Product,
  ProductSize,
  Subcategory,
} from '../types.ts';
import { CATEGORY_TAXONOMY, discountPercent, formatINR } from '../utils/format.ts';
import { ResilientImage } from './ResilientImage.tsx';

const ALL_SIZES: ProductSize[] = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One Size'];
const ALL_COLLECTIONS: CollectionTag[] = [
  'New Arrivals',
  'Trending',
  'Best Sellers',
  'Featured',
];

interface ProductFormState {
  id?: string;
  name: string;
  category: MainCategory;
  subcategory: Subcategory;
  description: string;
  fabricCare: string;
  price: number;
  originalPrice: number;
  stock: number;
  sizes: ProductSize[];
  colorName: string;
  colorHex: string;
  imageUrl: string;
  collections: CollectionTag[];
}

const emptyForm = (): ProductFormState => ({
  name: '',
  category: "Men's Fashion",
  subcategory: 'Shirts',
  description: '',
  fabricCare: '100% Natural Weave · Gentle cold wash',
  price: 2999,
  originalPrice: 3999,
  stock: 25,
  sizes: ['S', 'M', 'L', 'XL'],
  colorName: 'Midnight Indigo',
  colorHex: '#1E2B48',
  imageUrl: '/src/assets/images/mens_linen_shirt_1795244909118.jpg',
  collections: ['New Arrivals'],
});

export function AdminDashboard() {
  const { user, token, products, refreshProducts, setIsAuthModalOpen, notify } =
    useStore();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'products' | 'orders' | 'customers'
  >('overview');
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<CustomerSummary[]>([]);
  const [loadingData, setLoadingData] = useState(false);

  // Product modal
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<ProductFormState>(emptyForm());
  const [savingProduct, setSavingProduct] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [productSearch, setProductSearch] = useState('');

  const loadAdminData = useCallback(async () => {
    if (!token || user?.role !== 'admin') return;
    setLoadingData(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [statsRes, ordersRes, custRes] = await Promise.all([
        fetch('/api/admin/stats', { headers }),
        fetch('/api/admin/orders', { headers }),
        fetch('/api/admin/customers', { headers }),
      ]);
      if (statsRes.ok) {
        const s = (await statsRes.json()) as { stats: AdminStats };
        setStats(s.stats);
      }
      if (ordersRes.ok) {
        const o = (await ordersRes.json()) as { orders: Order[] };
        setOrders(o.orders);
      }
      if (custRes.ok) {
        const c = (await custRes.json()) as { customers: CustomerSummary[] };
        setCustomers(c.customers);
      }
    } finally {
      setLoadingData(false);
    }
  }, [token, user]);

  useEffect(() => {
    void loadAdminData();
  }, [loadAdminData]);

  if (!user || user.role !== 'admin') {
    return (
      <div className="max-w-lg mx-auto px-4 py-20 text-center">
        <ShieldAlert className="w-10 h-10 text-[#1E2B48] mx-auto mb-3" />
        <h1 className="font-editorial text-3xl font-semibold text-[#111315]">
          Store Admin Access Required
        </h1>
        <p className="text-sm text-[#64748B] mt-2">
          Sign in with an administrator account to manage inventory, pricing,
          images, orders, and store analytics.
        </p>
        <button
          type="button"
          onClick={() => setIsAuthModalOpen(true)}
          className="mt-6 px-6 py-3 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
        >
          Sign In as Admin
        </button>
      </div>
    );
  }

  const openCreateModal = () => {
    setForm(emptyForm());
    setModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setForm({
      id: product.id,
      name: product.name,
      category: product.category,
      subcategory: product.subcategory,
      description: product.description,
      fabricCare: product.fabricCare,
      price: product.price,
      originalPrice: product.originalPrice,
      stock: product.stock,
      sizes: product.sizes,
      colorName: product.colors[0]?.name || 'Obsidian',
      colorHex: product.colors[0]?.hex || '#111315',
      imageUrl: product.images[0] || '',
      collections: product.collections,
    });
    setModalOpen(true);
  };

  const handleImageFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !token) return;
    setUploadingImage(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error('Failed to read image file.'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/admin/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ filename: file.name, dataUrl }),
      });
      const data = (await res.json()) as { url?: string; error?: string };
      if (!res.ok || !data.url) {
        throw new Error(data.error || 'Image upload failed.');
      }
      setForm((prev) => ({ ...prev, imageUrl: data.url! }));
      notify('Product image uploaded to store storage.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Upload failed.', 'error');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setSavingProduct(true);
    try {
      const payload = {
        name: form.name,
        category: form.category,
        subcategory: form.subcategory,
        description: form.description,
        fabricCare: form.fabricCare,
        price: Number(form.price),
        originalPrice: Number(form.originalPrice),
        stock: Number(form.stock),
        sizes: form.sizes,
        colors: [{ name: form.colorName, hex: form.colorHex }],
        images: [form.imageUrl],
        collections: form.collections,
      };

      const url = form.id
        ? `/api/admin/products/${form.id}`
        : '/api/admin/products';
      const method = form.id ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });
      const data = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'Could not save product.');

      setModalOpen(false);
      await refreshProducts();
      await loadAdminData();
      notify(
        form.id ? 'Product updated successfully.' : 'New product published.',
        'success',
      );
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Save failed.', 'error');
    } finally {
      setSavingProduct(false);
    }
  };

  const handleQuickStock = async (product: Product, delta: number) => {
    if (!token) return;
    const nextStock = Math.max(0, product.stock + delta);
    const res = await fetch(`/api/admin/products/${product.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ stock: nextStock }),
    });
    if (res.ok) {
      await refreshProducts();
      await loadAdminData();
    }
  };

  const handleDeleteProduct = async (product: Product) => {
    if (!token) return;
    const res = await fetch(`/api/admin/products/${product.id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      notify(`Deleted ${product.name}.`, 'neutral');
      await refreshProducts();
      await loadAdminData();
    }
  };

  const handleOrderStatusChange = async (orderId: string, status: OrderStatus) => {
    if (!token) return;
    const res = await fetch(`/api/admin/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      notify(`Order ${orderId} marked ${status}.`, 'success');
      await loadAdminData();
    }
  };

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
      p.sku.toLowerCase().includes(productSearch.toLowerCase()) ||
      p.subcategory.toLowerCase().includes(productSearch.toLowerCase()),
  );

  return (
    <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 border-b border-[#E2E8F0]">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
            Merchant Operations Console
          </p>
          <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
            Vastra Atelier Admin
          </h1>
        </div>
        <button
          type="button"
          onClick={openCreateModal}
          className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md whitespace-nowrap cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Add New Product
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="mt-6 flex flex-wrap gap-2 border-b border-[#E2E8F0]">
        {[
          { id: 'overview' as const, label: 'Sales Overview', icon: BarChart3 },
          { id: 'products' as const, label: `Products & Inventory (${products.length})`, icon: ShoppingBag },
          { id: 'orders' as const, label: `Customer Orders (${orders.length})`, icon: Package },
          { id: 'customers' as const, label: `Customers (${customers.length})`, icon: Users },
        ].map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setActiveTab(t.id)}
              className={`inline-flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
                activeTab === t.id
                  ? 'border-[#111315] text-[#111315]'
                  : 'border-transparent text-[#64748B] hover:text-[#111315]'
              }`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="mt-8 space-y-8">
          {loadingData && !stats ? (
            <div className="h-36 bg-[#F1F3F5] rounded-lg animate-pulse" />
          ) : stats ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                <div className="bg-white border border-[#E2E8F0] rounded-lg p-5">
                  <p className="text-xs font-medium text-[#64748B]">Gross Revenue</p>
                  <p className="text-2xl font-semibold text-[#111315] tabular-nums mt-1">
                    {formatINR(stats.totalRevenue)}
                  </p>
                </div>
                <div className="bg-white border border-[#E2E8F0] rounded-lg p-5">
                  <p className="text-xs font-medium text-[#64748B]">Total Orders</p>
                  <p className="text-2xl font-semibold text-[#111315] tabular-nums mt-1">
                    {stats.totalOrders}
                  </p>
                </div>
                <div className="bg-white border border-[#E2E8F0] rounded-lg p-5">
                  <p className="text-xs font-medium text-[#64748B]">
                    Average Order Value
                  </p>
                  <p className="text-2xl font-semibold text-[#111315] tabular-nums mt-1">
                    {formatINR(stats.averageOrderValue)}
                  </p>
                </div>
                <div className="bg-white border border-[#E2E8F0] rounded-lg p-5">
                  <p className="text-xs font-medium text-[#64748B]">
                    Low Stock Items (&le;10)
                  </p>
                  <p className="text-2xl font-semibold text-[#1E2B48] tabular-nums mt-1">
                    {stats.lowStockCount}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white border border-[#E2E8F0] rounded-lg p-6">
                  <h2 className="font-sans text-base font-semibold text-[#111315] mb-4">
                    Revenue by Department
                  </h2>
                  <div className="space-y-4">
                    {stats.revenueByCategory.map((row) => {
                      const pct =
                        stats.totalRevenue > 0
                          ? Math.round((row.revenue / stats.totalRevenue) * 100)
                          : 0;
                      return (
                        <div key={row.category}>
                          <div className="flex justify-between text-xs font-medium mb-1">
                            <span className="text-[#111315]">{row.category}</span>
                            <span className="text-[#475569] tabular-nums">
                              {formatINR(row.revenue)} ({pct}%)
                            </span>
                          </div>
                          <div className="h-2 bg-[#F1F3F5] rounded-full overflow-hidden">
                            <div
                              className="h-full bg-[#1E2B48]"
                              style={{ width: `${Math.min(100, pct)}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-white border border-[#E2E8F0] rounded-lg p-6">
                  <h2 className="font-sans text-base font-semibold text-[#111315] mb-4">
                    Orders Pipeline
                  </h2>
                  <div className="divide-y divide-[#F1F5F9]">
                    {stats.ordersByStatus.map((row) => (
                      <div
                        key={row.status}
                        className="py-2.5 flex items-center justify-between text-sm"
                      >
                        <span className="text-[#475569]">{row.status}</span>
                        <span className="font-semibold text-[#111315] tabular-nums">
                          {row.count}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          ) : null}
        </div>
      )}

      {/* Products & Inventory Tab */}
      {activeTab === 'products' && (
        <div className="mt-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <input
              type="text"
              value={productSearch}
              onChange={(e) => setProductSearch(e.target.value)}
              placeholder="Filter products by name, SKU, or subcategory..."
              className="w-full sm:w-80 px-3.5 py-2 text-sm bg-white border border-[#CBD5E1] rounded-md"
            />
          </div>

          <div className="bg-white border border-[#E2E8F0] rounded-lg overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-[#E2E8F0] bg-[#F8F9FA] text-xs font-semibold text-[#64748B] uppercase tracking-wider">
                  <th className="py-3 px-4">Product</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Price / MRP</th>
                  <th className="py-3 px-4">Stock</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1F5F9]">
                {filteredProducts.map((p) => {
                  const pct = discountPercent(p.price, p.originalPrice);
                  return (
                    <tr key={p.id} className="hover:bg-[#F8F9FA]">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-11 h-11 rounded bg-[#F1F3F5] overflow-hidden shrink-0">
                            <ResilientImage
                              src={p.images[0] || ''}
                              alt={p.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <p className="font-semibold text-[#111315]">{p.name}</p>
                            <p className="text-xs font-mono text-[#64748B]">{p.sku}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-xs text-[#475569]">
                        {p.category} · {p.subcategory}
                      </td>
                      <td className="py-3 px-4 tabular-nums">
                        <span className="font-semibold text-[#111315]">
                          {formatINR(p.price)}
                        </span>
                        {pct > 0 && (
                          <span className="ml-2 text-xs text-[#64748B]">
                            ({pct}% off {formatINR(p.originalPrice)})
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="inline-flex items-center border border-[#CBD5E1] rounded bg-white">
                          <button
                            type="button"
                            onClick={() => void handleQuickStock(p, -1)}
                            aria-label={`Decrease stock for ${p.name}`}
                            className="p-1.5 text-[#475569] hover:text-[#111315] cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span
                            className={`px-2.5 text-xs font-semibold tabular-nums ${
                              p.stock <= 10 ? 'text-[#991B1B]' : 'text-[#111315]'
                            }`}
                          >
                            {p.stock}
                          </span>
                          <button
                            type="button"
                            onClick={() => void handleQuickStock(p, 1)}
                            aria-label={`Increase stock for ${p.name}`}
                            className="p-1.5 text-[#475569] hover:text-[#111315] cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => openEditModal(p)}
                          aria-label={`Edit ${p.name}`}
                          className="p-2 text-[#475569] hover:text-[#111315] cursor-pointer"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleDeleteProduct(p)}
                          aria-label={`Delete ${p.name}`}
                          className="p-2 text-[#475569] hover:text-[#991B1B] cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="mt-8 bg-white border border-[#E2E8F0] rounded-lg overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-[#E2E8F0] bg-[#F8F9FA] text-xs font-semibold text-[#64748B] uppercase tracking-wider">
                <th className="py-3 px-4">Order ID</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Items &amp; Destination</th>
                <th className="py-3 px-4">Payment</th>
                <th className="py-3 px-4">Total</th>
                <th className="py-3 px-4">Fulfillment Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F1F5F9]">
              {orders.map((ord) => (
                <tr key={ord.id} className="hover:bg-[#F8F9FA]">
                  <td className="py-3.5 px-4 font-mono text-xs font-semibold text-[#111315]">
                    {ord.id}
                    <div className="text-[11px] font-sans font-normal text-[#64748B] mt-0.5">
                      {new Date(ord.createdAt).toLocaleDateString('en-IN')}
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="font-medium text-[#111315]">{ord.customerName}</p>
                    <p className="text-xs text-[#64748B]">{ord.customerEmail}</p>
                  </td>
                  <td className="py-3.5 px-4 text-xs text-[#475569]">
                    <p className="font-medium text-[#111315]">
                      {ord.items.map((i) => `${i.name} (${i.size}) ×${i.quantity}`).join(', ')}
                    </p>
                    <p className="text-[#64748B] mt-0.5">
                      {ord.shippingAddress.city}, {ord.shippingAddress.state} -{' '}
                      {ord.shippingAddress.pinCode}
                    </p>
                  </td>
                  <td className="py-3.5 px-4 text-xs">
                    <span className="font-semibold text-[#111315]">
                      {ord.paymentMethod}
                    </span>
                    <div className="text-[#64748B]">{ord.paymentStatus}</div>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-[#111315] tabular-nums">
                    {formatINR(ord.total)}
                  </td>
                  <td className="py-3.5 px-4">
                    <select
                      aria-label={`Order status for ${ord.id}`}
                      value={ord.status}
                      onChange={(e) =>
                        void handleOrderStatusChange(
                          ord.id,
                          e.target.value as OrderStatus,
                        )
                      }
                      className="px-2.5 py-1.5 text-xs font-semibold bg-white border border-[#CBD5E1] rounded-md text-[#111315]"
                    >
                      {(['Placed', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'] as OrderStatus[]).map(
                        (st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ),
                      )}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Customers Tab */}
      {activeTab === 'customers' && (
        <div className="mt-8 bg-white border border-[#E2E8F0] rounded-lg overflow-x-auto">
          <table className="w-full text-left text-sm border-collapse">
            <thead>
              <tr className="border-b border-[#E2E8F0] bg-[#F8F9FA] text-xs font-semibold text-[#64748B] uppercase tracking-wider">
                <th className="py-3 px-4">Name</th>
                <th className="py-3 px-4">Contact</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Orders</th>
                <th className="py-3 px-4">Lifetime Spend</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F1F5F9]">
              {customers.map((c) => (
                <tr key={c.id} className="hover:bg-[#F8F9FA]">
                  <td className="py-3.5 px-4 font-semibold text-[#111315]">
                    {c.name}
                  </td>
                  <td className="py-3.5 px-4 text-xs text-[#475569]">
                    <div>{c.email}</div>
                    <div className="tabular-nums text-[#64748B]">{c.phone}</div>
                  </td>
                  <td className="py-3.5 px-4 text-xs capitalize text-[#475569]">
                    {c.role}
                  </td>
                  <td className="py-3.5 px-4 text-sm font-medium tabular-nums">
                    {c.orderCount}
                  </td>
                  <td className="py-3.5 px-4 text-sm font-semibold text-[#111315] tabular-nums">
                    {formatINR(c.totalSpent)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/55 p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-label="Product Editor"
        >
          <div className="bg-white w-full max-w-2xl rounded-xl border border-[#E2E8F0] shadow-2xl overflow-hidden my-8">
            <div className="px-6 py-4 border-b border-[#E2E8F0] flex items-center justify-between">
              <h2 className="font-editorial text-2xl font-semibold text-[#111315]">
                {form.id ? 'Edit Product' : 'Add New Product'}
              </h2>
              <button
                type="button"
                onClick={() => setModalOpen(false)}
                className="p-1 text-[#64748B] hover:text-[#111315] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={handleSaveProduct}
              className="p-6 space-y-4 max-h-[80vh] overflow-y-auto"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Product Name
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g. Jaipur Handloom Linen Kurta"
                    className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Department
                  </label>
                  <select
                    value={form.category}
                    onChange={(e) => {
                      const cat = e.target.value as MainCategory;
                      setForm({
                        ...form,
                        category: cat,
                        subcategory: CATEGORY_TAXONOMY[cat][0],
                      });
                    }}
                    className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md bg-white"
                  >
                    {(Object.keys(CATEGORY_TAXONOMY) as MainCategory[]).map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Subcategory
                  </label>
                  <select
                    value={form.subcategory}
                    onChange={(e) =>
                      setForm({ ...form, subcategory: e.target.value as Subcategory })
                    }
                    className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md bg-white"
                  >
                    {CATEGORY_TAXONOMY[form.category].map((sub) => (
                      <option key={sub} value={sub}>
                        {sub}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Selling Price (₹)
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={form.price}
                    onChange={(e) =>
                      setForm({ ...form, price: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Original MRP (₹)
                  </label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={form.originalPrice}
                    onChange={(e) =>
                      setForm({ ...form, originalPrice: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Stock Quantity
                  </label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={form.stock}
                    onChange={(e) =>
                      setForm({ ...form, stock: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md tabular-nums"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#475569] mb-1">
                    Primary Colour Name &amp; Swatch
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={form.colorName}
                      onChange={(e) =>
                        setForm({ ...form, colorName: e.target.value })
                      }
                      className="flex-1 px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
                    />
                    <input
                      type="color"
                      value={form.colorHex}
                      onChange={(e) =>
                        setForm({ ...form, colorHex: e.target.value })
                      }
                      className="w-11 h-9 p-1 border border-[#CBD5E1] rounded-md bg-white cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  required
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md"
                />
              </div>

              {/* Image Upload & URL */}
              <div className="p-4 bg-[#F8F9FA] border border-[#E2E8F0] rounded-lg space-y-3">
                <label className="block text-xs font-semibold text-[#111315]">
                  Product Image (Upload from Device or Paste Path)
                </label>
                <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
                  <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#111315] bg-white border border-[#CBD5E1] hover:border-[#111315] rounded-md cursor-pointer">
                    <Upload className="w-3.5 h-3.5" />
                    {uploadingImage ? 'Uploading...' : 'Upload Image File'}
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      onChange={handleImageFileUpload}
                      className="hidden"
                    />
                  </label>
                  <input
                    type="text"
                    value={form.imageUrl}
                    onChange={(e) =>
                      setForm({ ...form, imageUrl: e.target.value })
                    }
                    placeholder="/uploads/..."
                    className="flex-1 w-full px-3 py-2 text-xs bg-white border border-[#CBD5E1] rounded-md"
                  />
                </div>
              </div>

              {/* Sizes */}
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1.5">
                  Available Sizes
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_SIZES.map((sz) => {
                    const checked = form.sizes.includes(sz);
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() =>
                          setForm((prev) => ({
                            ...prev,
                            sizes: checked
                              ? prev.sizes.filter((s) => s !== sz)
                              : [...prev.sizes, sz],
                          }))
                        }
                        className={`px-3 py-1 text-xs font-semibold rounded border cursor-pointer ${
                          checked
                            ? 'bg-[#111315] text-white border-[#111315]'
                            : 'bg-white text-[#475569] border-[#CBD5E1]'
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Collections */}
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1.5">
                  Homepage Collections
                </label>
                <div className="flex flex-wrap gap-2">
                  {ALL_COLLECTIONS.map((col) => {
                    const checked = form.collections.includes(col);
                    return (
                      <button
                        key={col}
                        type="button"
                        onClick={() =>
                          setForm((prev) => ({
                            ...prev,
                            collections: checked
                              ? prev.collections.filter((c) => c !== col)
                              : [...prev.collections, col],
                          }))
                        }
                        className={`px-3 py-1 text-xs font-semibold rounded border cursor-pointer ${
                          checked
                            ? 'bg-[#1E2B48] text-white border-[#1E2B48]'
                            : 'bg-white text-[#475569] border-[#CBD5E1]'
                        }`}
                      >
                        {col}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 border-t border-[#E2E8F0] flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#475569] border border-[#CBD5E1] rounded-md cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProduct}
                  className="px-5 py-2 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
                >
                  {savingProduct ? 'Saving...' : form.id ? 'Save Changes' : 'Publish Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

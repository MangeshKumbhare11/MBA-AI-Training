import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { useStore } from '../context/StoreContext.tsx';
import { formatINR } from '../utils/format.ts';
import { ResilientImage } from './ResilientImage.tsx';

interface CartDrawerProps {
  onCheckout: () => void;
  onBrowseCatalog: () => void;
}

export function CartDrawer({ onCheckout, onBrowseCatalog }: CartDrawerProps) {
  const {
    cart,
    cartCount,
    cartSubtotal,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
  } = useStore();

  if (!isCartOpen) return null;

  const freeShippingThreshold = 2999;
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - cartSubtotal);
  const progressPct = Math.min(100, Math.round((cartSubtotal / freeShippingThreshold) * 100));

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-black/45 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-label="Shopping Bag"
    >
      <div
        className="flex-1"
        onClick={() => setIsCartOpen(false)}
        aria-hidden="true"
      />
      <aside className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl border-l border-[#E2E8F0]">
        <div className="px-6 py-4 border-b border-[#E2E8F0] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4.5 h-4.5 text-[#111315]" />
            <h2 className="font-sans text-base font-semibold text-[#111315]">
              Shopping Bag ({cartCount})
            </h2>
          </div>
          <button
            type="button"
            onClick={() => setIsCartOpen(false)}
            aria-label="Close shopping bag"
            className="p-2 text-[#64748B] hover:text-[#111315] rounded-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-6 py-3 bg-[#F8F9FA] border-b border-[#E2E8F0]">
          <p className="text-xs text-[#475569] mb-2">
            {remainingForFreeShipping === 0
              ? 'You qualify for complimentary Pan-India Express Shipping.'
              : `Add ${formatINR(remainingForFreeShipping)} more for complimentary Pan-India shipping.`}
          </p>
          <div className="w-full h-1.5 bg-[#E2E8F0] rounded-full overflow-hidden">
            <div
              className="h-full bg-[#1E2B48] transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-[#F1F5F9]">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <ShoppingBag className="w-10 h-10 text-[#94A3B8] mb-3" strokeWidth={1.5} />
              <p className="text-base font-semibold text-[#111315]">
                Your shopping bag is empty
              </p>
              <p className="text-sm text-[#64748B] mt-1 max-w-xs">
                Explore handcrafted kurtis, tailored menswear, and fine leather accessories.
              </p>
              <button
                type="button"
                onClick={() => {
                  setIsCartOpen(false);
                  onBrowseCatalog();
                }}
                className="mt-5 px-5 py-2.5 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md cursor-pointer"
              >
                Explore Collection
              </button>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={`${item.productId}-${item.size}-${item.color}`}
                className="py-4 flex gap-4"
              >
                <div className="w-20 h-20 rounded-md overflow-hidden bg-[#F1F3F5] shrink-0 border border-[#E2E8F0]">
                  <ResilientImage
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-[#111315] truncate">
                        {item.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() =>
                          removeFromCart(item.productId, item.size, item.color)
                        }
                        aria-label={`Remove ${item.name}`}
                        className="text-[#94A3B8] hover:text-[#B91C1C] p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-[#64748B] mt-0.5">
                      Size: {item.size} · {item.color}
                    </p>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <div className="inline-flex items-center border border-[#CBD5E1] rounded-md">
                      <button
                        type="button"
                        onClick={() =>
                          updateCartQuantity(
                            item.productId,
                            item.size,
                            item.color,
                            item.quantity - 1,
                          )
                        }
                        aria-label="Decrease quantity"
                        className="p-1.5 text-[#475569] hover:text-[#111315] cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-2.5 text-xs font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          updateCartQuantity(
                            item.productId,
                            item.size,
                            item.color,
                            item.quantity + 1,
                          )
                        }
                        disabled={item.quantity >= item.maxStock}
                        aria-label="Increase quantity"
                        className="p-1.5 text-[#475569] hover:text-[#111315] disabled:opacity-40 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="text-sm font-semibold text-[#111315] tabular-nums">
                      {formatINR(item.price * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="p-6 border-t border-[#E2E8F0] bg-[#F8F9FA] space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[#475569]">Subtotal (inclusive of all taxes)</span>
              <span className="text-base font-semibold text-[#111315] tabular-nums">
                {formatINR(cartSubtotal)}
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setIsCartOpen(false);
                onCheckout();
              }}
              className="w-full py-3 px-4 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md transition-colors cursor-pointer"
            >
              Proceed to Checkout
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}

import { Search, SlidersHorizontal, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type { CollectionTag, MainCategory, ProductSize } from '../types.ts';
import { CATEGORY_TAXONOMY, formatINR } from '../utils/format.ts';
import { ProductCard } from './ProductCard.tsx';

interface CatalogPageProps {
  initialCategory?: MainCategory | 'All';
  initialSubcategory?: string;
  initialCollection?: string;
  initialSearch?: string;
  onSelectProduct: (productId: string) => void;
}

const ALL_SIZES: ProductSize[] = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'One Size'];

export function CatalogPage({
  initialCategory = 'All',
  initialSubcategory = 'All',
  initialCollection = 'All',
  initialSearch = '',
  onSelectProduct,
}: CatalogPageProps) {
  const { products, productsLoading, productsError, refreshProducts } = useStore();

  const [category, setCategory] = useState<MainCategory | 'All'>(initialCategory);
  const [subcategory, setSubcategory] = useState<string>(initialSubcategory);
  const [collection, setCollection] = useState<string>(initialCollection);
  const [search, setSearch] = useState<string>(initialSearch);
  const [selectedSize, setSelectedSize] = useState<string>('All');
  const [selectedColor, setSelectedColor] = useState<string>('All');
  const [maxPrice, setMaxPrice] = useState<number>(20000);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => {
    setCategory(initialCategory);
    setSubcategory(initialSubcategory || 'All');
    setCollection(initialCollection || 'All');
    setSearch(initialSearch || '');
  }, [initialCategory, initialSubcategory, initialCollection, initialSearch]);

  const availableSubcategories = useMemo(() => {
    if (category === 'All') {
      return Array.from(
        new Set(Object.values(CATEGORY_TAXONOMY).flat()),
      );
    }
    return CATEGORY_TAXONOMY[category];
  }, [category]);

  const availableColors = useMemo(() => {
    const names = new Set<string>();
    products.forEach((p) => p.colors.forEach((c) => names.add(c.name)));
    return Array.from(names).slice(0, 12);
  }, [products]);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = products.filter((p) => {
      if (category !== 'All' && p.category !== category) return false;
      if (subcategory !== 'All' && p.subcategory !== subcategory) return false;
      if (
        collection !== 'All' &&
        !p.collections.includes(collection as CollectionTag)
      ) {
        return false;
      }
      if (selectedSize !== 'All' && !p.sizes.includes(selectedSize as ProductSize)) {
        return false;
      }
      if (
        selectedColor !== 'All' &&
        !p.colors.some((c) => c.name === selectedColor)
      ) {
        return false;
      }
      if (p.price > maxPrice) return false;
      if (q) {
        const hay = `${p.name} ${p.category} ${p.subcategory} ${p.description}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    switch (sortBy) {
      case 'price_asc':
        return [...list].sort((a, b) => a.price - b.price);
      case 'price_desc':
        return [...list].sort((a, b) => b.price - a.price);
      case 'rating':
        return [...list].sort((a, b) => b.rating - a.rating);
      case 'newest':
        return [...list].sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
      default:
        return list;
    }
  }, [
    products,
    category,
    subcategory,
    collection,
    search,
    selectedSize,
    selectedColor,
    maxPrice,
    sortBy,
  ]);

  const resetFilters = () => {
    setCategory('All');
    setSubcategory('All');
    setCollection('All');
    setSearch('');
    setSelectedSize('All');
    setSelectedColor('All');
    setMaxPrice(20000);
    setSortBy('featured');
  };

  return (
    <div className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[#E2E8F0]">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#64748B]">
            {category === 'All' ? 'Complete Collection' : category}
            {subcategory !== 'All' ? ` · ${subcategory}` : ''}
          </p>
          <h1 className="font-editorial text-3xl sm:text-4xl font-semibold text-[#111315] mt-1">
            {collection !== 'All' ? collection : category === 'All' ? 'All Apparel & Accessories' : category}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-[#64748B] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search items..."
              className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315]"
            />
          </div>

          <select
            aria-label="Sort products"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-3 py-2 text-sm bg-white border border-[#CBD5E1] rounded-md text-[#111315] focus:outline-none focus:border-[#111315]"
          >
            <option value="featured">Sort: Featured</option>
            <option value="newest">Sort: Newest</option>
            <option value="price_asc">Price: Low to High</option>
            <option value="price_desc">Price: High to Low</option>
            <option value="rating">Top Rated</option>
          </select>

          <button
            type="button"
            onClick={() => setFiltersOpen((v) => !v)}
            className="lg:hidden inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium border border-[#CBD5E1] bg-white rounded-md"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
          </button>
        </div>
      </div>

      {/* Category & Subcategory Strip */}
      <div className="py-4 border-b border-[#E2E8F0] flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {(['All', "Men's Fashion", "Women's Fashion", 'Accessories'] as const).map(
            (cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  setCategory(cat);
                  setSubcategory('All');
                }}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  category === cat
                    ? 'bg-[#111315] text-white'
                    : 'bg-white text-[#475569] border border-[#E2E8F0] hover:border-[#111315]'
                }`}
              >
                {cat}
              </button>
            ),
          )}
        </div>

        <p className="text-xs text-[#64748B] tabular-nums">
          Showing {filteredProducts.length} of {products.length} pieces
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Filter Sidebar */}
        <aside
          className={`lg:col-span-3 space-y-6 ${
            filtersOpen ? 'block' : 'hidden lg:block'
          }`}
        >
          <div className="bg-white border border-[#E2E8F0] rounded-lg p-5 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="font-sans text-sm font-semibold text-[#111315]">
                Refine Selection
              </h2>
              <button
                type="button"
                onClick={resetFilters}
                className="text-xs font-medium text-[#1E2B48] hover:underline cursor-pointer"
              >
                Reset All
              </button>
            </div>

            {/* Subcategory */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2.5">
                Subcategory
              </label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setSubcategory('All')}
                  className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                    subcategory === 'All'
                      ? 'bg-[#111315] text-white border-[#111315]'
                      : 'bg-[#F8F9FA] text-[#475569] border-[#E2E8F0] hover:border-[#111315]'
                  }`}
                >
                  All
                </button>
                {availableSubcategories.map((sub) => (
                  <button
                    key={sub}
                    type="button"
                    onClick={() => setSubcategory(sub)}
                    className={`px-2.5 py-1 text-xs rounded border transition-colors cursor-pointer ${
                      subcategory === sub
                        ? 'bg-[#111315] text-white border-[#111315]'
                        : 'bg-[#F8F9FA] text-[#475569] border-[#E2E8F0] hover:border-[#111315]'
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label
                  htmlFor="price-range"
                  className="text-xs font-semibold uppercase tracking-wider text-[#64748B]"
                >
                  Max Price
                </label>
                <span className="text-xs font-semibold text-[#111315] tabular-nums">
                  Up to {formatINR(maxPrice)}
                </span>
              </div>
              <input
                id="price-range"
                type="range"
                min={1500}
                max={20000}
                step={500}
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
                className="w-full accent-[#111315]"
              />
              <div className="flex justify-between text-[11px] text-[#94A3B8] tabular-nums mt-1">
                <span>₹1,500</span>
                <span>₹20,000</span>
              </div>
            </div>

            {/* Size */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2.5">
                Size
              </label>
              <div className="flex flex-wrap gap-1.5">
                {(['All', ...ALL_SIZES] as const).map((sz) => (
                  <button
                    key={sz}
                    type="button"
                    onClick={() => setSelectedSize(sz)}
                    className={`px-2.5 py-1 text-xs font-medium rounded border transition-colors cursor-pointer ${
                      selectedSize === sz
                        ? 'bg-[#111315] text-white border-[#111315]'
                        : 'bg-white text-[#475569] border-[#CBD5E1] hover:border-[#111315]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Color */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2">
                Colour
              </label>
              <select
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#CBD5E1] rounded-md text-[#111315]"
              >
                <option value="All">All Colours</option>
                {availableColors.map((colorName) => (
                  <option key={colorName} value={colorName}>
                    {colorName}
                  </option>
                ))}
              </select>
            </div>

            {/* Collection */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2">
                Collection
              </label>
              <select
                value={collection}
                onChange={(e) => setCollection(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-[#CBD5E1] rounded-md text-[#111315]"
              >
                <option value="All">All Collections</option>
                <option value="New Arrivals">New Arrivals</option>
                <option value="Trending">Trending</option>
                <option value="Best Sellers">Best Sellers</option>
                <option value="Featured">Featured</option>
              </select>
            </div>
          </div>
        </aside>

        {/* Product Grid */}
        <div className="lg:col-span-9">
          {productsError ? (
            <div className="p-8 bg-white border border-[#FECACA] rounded-lg text-center">
              <p className="text-sm font-medium text-[#991B1B]">{productsError}</p>
              <button
                type="button"
                onClick={() => void refreshProducts()}
                className="mt-4 px-4 py-2 text-xs font-semibold text-white bg-[#111315] rounded-md"
              >
                Retry Loading Catalog
              </button>
            </div>
          ) : productsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-88 bg-[#E2E8F0]/50 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="p-12 bg-white border border-[#E2E8F0] rounded-lg text-center">
              <X className="w-8 h-8 text-[#94A3B8] mx-auto mb-3" />
              <h3 className="text-base font-semibold text-[#111315]">
                No matching pieces found
              </h3>
              <p className="text-sm text-[#64748B] mt-1">
                Try adjusting your price ceiling, size, or category filters.
              </p>
              <button
                type="button"
                onClick={resetFilters}
                className="mt-5 px-5 py-2.5 text-xs font-semibold text-white bg-[#111315] rounded-md cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onSelect={onSelectProduct}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

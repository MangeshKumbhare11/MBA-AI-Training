import { Heart, Menu, Search, ShoppingBag, User, X } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import type { MainCategory } from '../types.ts';

export type AppRoute =
  | { view: 'home' }
  | { view: 'catalog'; category?: MainCategory | 'All'; subcategory?: string; collection?: string; search?: string }
  | { view: 'product'; productId: string }
  | { view: 'checkout' }
  | { view: 'account'; tab?: 'orders' | 'wishlist' | 'profile' }
  | { view: 'admin' };

interface HeaderProps {
  route: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

export function Header({ route, onNavigate }: HeaderProps) {
  const { user, cartCount, setIsCartOpen, wishlistIds, setIsAuthModalOpen } =
    useStore();
  const [bannerDismissed, setBannerDismissed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate({ view: 'catalog', category: 'All', search: searchQuery.trim() });
    setSearchOpen(false);
  };

  const navItems: { label: string; active: boolean; action: () => void }[] = [
    {
      label: 'Men',
      active: route.view === 'catalog' && route.category === "Men's Fashion",
      action: () => onNavigate({ view: 'catalog', category: "Men's Fashion" }),
    },
    {
      label: 'Women',
      active: route.view === 'catalog' && route.category === "Women's Fashion",
      action: () => onNavigate({ view: 'catalog', category: "Women's Fashion" }),
    },
    {
      label: 'Accessories',
      active: route.view === 'catalog' && route.category === 'Accessories',
      action: () => onNavigate({ view: 'catalog', category: 'Accessories' }),
    },
    {
      label: 'Collections',
      active: route.view === 'catalog' && route.category === 'All',
      action: () => onNavigate({ view: 'catalog', category: 'All' }),
    },
    {
      label: 'Admin',
      active: route.view === 'admin',
      action: () => {
        if (!user || user.role !== 'admin') {
          setIsAuthModalOpen(true);
        } else {
          onNavigate({ view: 'admin' });
        }
      },
    },
  ];

  return (
    <div className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-[#E2E8F0]">
      {!bannerDismissed && (
        <div className="bg-[#111315] text-white h-8 px-4 flex items-center justify-between text-xs tracking-wide">
          <span className="w-4" aria-hidden="true" />
          <p className="truncate text-center">
            Complimentary Pan-India Express Shipping above ₹2,999 · Code{' '}
            <span className="font-mono font-medium underline underline-offset-2">
              WELCOME15
            </span>
          </p>
          <button
            type="button"
            onClick={() => setBannerDismissed(true)}
            aria-label="Dismiss promotional announcement"
            className="p-1 text-white/70 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      <header className="max-w-[1320px] mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            aria-label="Toggle navigation menu"
            className="md:hidden p-2 -ml-2 text-[#111315] hover:bg-[#F1F3F5] rounded-md"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <button
            type="button"
            onClick={() => onNavigate({ view: 'home' })}
            className="font-editorial text-2xl font-semibold tracking-tight text-[#111315] whitespace-nowrap shrink-0 cursor-pointer"
          >
            Vastra Atelier
          </button>
        </div>

        {/* Zone 2: Clean single-line navigation links */}
        <nav
          aria-label="Main navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-[#475569]"
        >
          {navItems.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={item.action}
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                item.active
                  ? 'text-[#111315] border-[#111315]'
                  : 'border-transparent hover:text-[#111315] hover:border-[#CBD5E1]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Search, Account, Wishlist, and Primary Bag Action */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setSearchOpen((v) => !v)}
            aria-label="Search products"
            className="p-2 text-[#475569] hover:text-[#111315] hover:bg-[#F1F3F5] rounded-md transition-colors cursor-pointer"
          >
            <Search className="w-4.5 h-4.5" />
          </button>

          <button
            type="button"
            onClick={() => {
              if (user) {
                onNavigate({ view: 'account', tab: 'wishlist' });
              } else {
                onNavigate({ view: 'catalog', category: 'All' });
              }
            }}
            aria-label="Wishlist"
            className="hidden sm:inline-flex items-center gap-1 p-2 text-[#475569] hover:text-[#111315] hover:bg-[#F1F3F5] rounded-md transition-colors cursor-pointer relative"
          >
            <Heart className="w-4.5 h-4.5" />
            {wishlistIds.length > 0 && (
              <span className="text-[11px] font-medium tabular-nums text-[#111315]">
                {wishlistIds.length}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              if (user) {
                onNavigate({ view: 'account', tab: 'orders' });
              } else {
                setIsAuthModalOpen(true);
              }
            }}
            aria-label={user ? 'My Account' : 'Sign In'}
            className="inline-flex items-center gap-1.5 px-2.5 py-2 text-sm font-medium text-[#475569] hover:text-[#111315] hover:bg-[#F1F3F5] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <User className="w-4.5 h-4.5" />
            <span className="hidden lg:inline max-w-[110px] truncate">
              {user ? user.name.split(' ')[0] : 'Sign In'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold tracking-wide text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="tabular-nums">Bag ({cartCount})</span>
          </button>
        </div>
      </header>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="border-t border-[#E2E8F0] bg-[#F8F9FA] px-4 sm:px-6 lg:px-8 py-3">
          <form
            onSubmit={handleSearchSubmit}
            className="max-w-[720px] mx-auto flex items-center gap-2"
          >
            <Search className="w-4 h-4 text-[#64748B] shrink-0" />
            <input
              type="text"
              autoFocus
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search kurtis, linen shirts, Banarasi sarees, watches..."
              className="w-full bg-white border border-[#CBD5E1] rounded-md px-3 py-2 text-sm text-[#111315] focus:outline-none focus:border-[#111315]"
            />
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] rounded-md whitespace-nowrap shrink-0"
            >
              Search
            </button>
            <button
              type="button"
              onClick={() => setSearchOpen(false)}
              aria-label="Close search"
              className="p-2 text-[#64748B] hover:text-[#111315]"
            >
              <X className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-[#E2E8F0] bg-white px-4 py-4 flex flex-col gap-2"
        >
          {navItems.map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => {
                item.action();
                setMobileMenuOpen(false);
              }}
              className={`text-left px-3 py-2.5 text-sm font-medium rounded-md ${
                item.active
                  ? 'bg-[#F1F3F5] text-[#111315]'
                  : 'text-[#475569] hover:bg-[#F8F9FA]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>
      )}
    </div>
  );
}

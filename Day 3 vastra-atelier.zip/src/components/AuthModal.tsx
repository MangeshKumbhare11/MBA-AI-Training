import { ShieldCheck, X } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';

interface AuthModalProps {
  onSuccessAdmin?: () => void;
}

export function AuthModal({ onSuccessAdmin }: AuthModalProps) {
  const { isAuthModalOpen, setIsAuthModalOpen, login, register, notify } =
    useStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const profile =
        mode === 'login'
          ? await login(email, password)
          : await register({ name, email, phone, password });
      notify(`Welcome, ${profile.name.split(' ')[0]}.`, 'success');
      setIsAuthModalOpen(false);
      if (profile.role === 'admin' && onSuccessAdmin) {
        onSuccessAdmin();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const fillDemo = (role: 'customer' | 'admin') => {
    setMode('login');
    setError(null);
    if (role === 'admin') {
      setEmail('admin@vastraatelier.in');
      setPassword('Admin@123');
    } else {
      setEmail('aarav.sharma@example.in');
      setPassword('Customer@123');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Account Sign In"
    >
      <div className="bg-white w-full max-w-md rounded-xl border border-[#E2E8F0] shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-[#E2E8F0] flex items-center justify-between">
          <h2 className="font-editorial text-2xl font-semibold text-[#111315]">
            {mode === 'login' ? 'Sign In to Vastra Atelier' : 'Create Your Account'}
          </h2>
          <button
            type="button"
            onClick={() => setIsAuthModalOpen(false)}
            aria-label="Close authentication modal"
            className="p-1.5 text-[#64748B] hover:text-[#111315] rounded-md cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="flex border border-[#E2E8F0] rounded-lg p-1 bg-[#F8F9FA]">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-[#111315] shadow-xs'
                  : 'text-[#64748B]'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                mode === 'register'
                  ? 'bg-white text-[#111315] shadow-xs'
                  : 'text-[#64748B]'
              }`}
            >
              Register
            </button>
          </div>

          {error && (
            <div className="p-3 text-xs font-medium text-[#991B1B] bg-[#FEF2F2] border border-[#FECACA] rounded-md">
              {error}
            </div>
          )}

          {mode === 'register' && (
            <>
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Priya Deshmukh"
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315]"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#475569] mb-1">
                  Mobile Number (+91)
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="9820011223"
                  className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315]"
                />
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.in"
              className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#475569] mb-1">
              Password
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 text-sm border border-[#CBD5E1] rounded-md focus:outline-none focus:border-[#111315]"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#111315] hover:bg-[#1E2B48] disabled:opacity-60 rounded-md transition-colors cursor-pointer"
          >
            {submitting
              ? 'Please wait...'
              : mode === 'login'
                ? 'Sign In'
                : 'Create Account'}
          </button>

          <div className="pt-3 border-t border-[#E2E8F0]">
            <p className="text-[11px] font-medium text-[#64748B] flex items-center gap-1.5 mb-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#1E2B48]" />
              Quick Demo Access
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => fillDemo('customer')}
                className="px-3 py-1.5 text-xs font-medium text-[#111315] border border-[#CBD5E1] hover:border-[#111315] rounded-md cursor-pointer"
              >
                Fill Customer Demo
              </button>
              <button
                type="button"
                onClick={() => fillDemo('admin')}
                className="px-3 py-1.5 text-xs font-medium text-[#1E2B48] border border-[#CBD5E1] hover:border-[#1E2B48] rounded-md cursor-pointer"
              >
                Fill Admin Demo
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

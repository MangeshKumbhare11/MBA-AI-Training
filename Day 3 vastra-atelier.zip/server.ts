import crypto from 'crypto';
import dotenv from 'dotenv';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import {
  ensureDataDirs,
  getStore,
  hashPassword,
  sanitizeUser,
  saveStore,
  signToken,
  UPLOADS_DIR,
  verifyPassword,
  verifyToken,
} from './src/server/db.ts';
import type {
  AdminStats,
  CustomerSummary,
  Order,
  OrderStatus,
  PaymentMethod,
  Product,
  ProductReview,
  ShippingAddress,
  UserRole,
} from './src/types.ts';

dotenv.config();

interface AuthedRequest extends Request {
  auth?: {
    userId: string;
    role: UserRole;
  };
}

function parseAuthHeader(req: AuthedRequest, _res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  if (header && header.startsWith('Bearer ')) {
    const token = header.slice(7).trim();
    const verified = verifyToken(token);
    if (verified) {
      req.auth = { userId: verified.sub, role: verified.role };
    }
  }
  next();
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Please sign in to continue.' });
    return;
  }
  next();
}

function requireAdmin(req: AuthedRequest, res: Response, next: NextFunction) {
  if (!req.auth) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  if (req.auth.role !== 'admin') {
    res.status(403).json({ error: 'Administrator privileges required.' });
    return;
  }
  next();
}

function calculateDiscount(
  subtotal: number,
  couponCode?: string,
): { discount: number; validCode?: string; error?: string } {
  if (!couponCode || !couponCode.trim()) return { discount: 0 };
  const store = getStore();
  const normalized = couponCode.trim().toUpperCase();
  const coupon = store.coupons.find((c) => c.code === normalized);
  if (!coupon) {
    return { discount: 0, error: 'Invalid coupon code.' };
  }
  if (subtotal < coupon.minOrder) {
    return {
      discount: 0,
      error: `Minimum order of ₹${coupon.minOrder.toLocaleString('en-IN')} required for ${coupon.code}.`,
    };
  }
  let discount =
    coupon.type === 'percent'
      ? Math.round((subtotal * coupon.value) / 100)
      : coupon.value;
  if (coupon.maxDiscount && discount > coupon.maxDiscount) {
    discount = coupon.maxDiscount;
  }
  discount = Math.min(discount, subtotal);
  return { discount, validCode: coupon.code };
}

async function startServer() {
  ensureDataDirs();
  getStore();

  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '12mb' }));
  app.use(parseAuthHeader);
  app.use('/uploads', express.static(UPLOADS_DIR));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', store: 'Vastra Atelier' });
  });

  // Public products listing with filtering & sorting
  app.get('/api/products', (req, res) => {
    const store = getStore();
    let items = [...store.products];

    const category = typeof req.query.category === 'string' ? req.query.category : '';
    const subcategory =
      typeof req.query.subcategory === 'string' ? req.query.subcategory : '';
    const collection =
      typeof req.query.collection === 'string' ? req.query.collection : '';
    const search =
      typeof req.query.search === 'string' ? req.query.search.trim().toLowerCase() : '';
    const size = typeof req.query.size === 'string' ? req.query.size : '';
    const color = typeof req.query.color === 'string' ? req.query.color : '';
    const minPrice = Number(req.query.minPrice || 0);
    const maxPrice = Number(req.query.maxPrice || 0);
    const sort = typeof req.query.sort === 'string' ? req.query.sort : 'featured';

    if (category && category !== 'All') {
      items = items.filter((p) => p.category === category);
    }
    if (subcategory && subcategory !== 'All') {
      items = items.filter((p) => p.subcategory === subcategory);
    }
    if (collection && collection !== 'All') {
      items = items.filter((p) => p.collections.includes(collection as never));
    }
    if (search) {
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(search) ||
          p.category.toLowerCase().includes(search) ||
          p.subcategory.toLowerCase().includes(search) ||
          p.description.toLowerCase().includes(search),
      );
    }
    if (size && size !== 'All') {
      items = items.filter((p) => p.sizes.includes(size as never));
    }
    if (color && color !== 'All') {
      items = items.filter((p) =>
        p.colors.some((c) => c.name.toLowerCase() === color.toLowerCase()),
      );
    }
    if (minPrice > 0) {
      items = items.filter((p) => p.price >= minPrice);
    }
    if (maxPrice > 0) {
      items = items.filter((p) => p.price <= maxPrice);
    }

    switch (sort) {
      case 'price_asc':
        items.sort((a, b) => a.price - b.price);
        break;
      case 'price_desc':
        items.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        items.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        items.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        );
        break;
      default:
        items.sort((a, b) => {
          const aFeat = a.collections.includes('Featured') ? 1 : 0;
          const bFeat = b.collections.includes('Featured') ? 1 : 0;
          return bFeat - aFeat;
        });
        break;
    }

    res.json({ products: items });
  });

  app.get('/api/products/:idOrSlug', (req, res) => {
    const store = getStore();
    const product = store.products.find(
      (p) => p.id === req.params.idOrSlug || p.slug === req.params.idOrSlug,
    );
    if (!product) {
      res.status(404).json({ error: 'Product not found.' });
      return;
    }
    res.json({ product });
  });

  // Submit review
  app.post('/api/products/:id/reviews', requireAuth, (req: AuthedRequest, res) => {
    const store = getStore();
    const product = store.products.find((p) => p.id === req.params.id);
    if (!product) {
      res.status(404).json({ error: 'Product not found.' });
      return;
    }
    const user = store.users.find((u) => u.id === req.auth?.userId);
    if (!user) {
      res.status(401).json({ error: 'User not found.' });
      return;
    }

    const rating = Number(req.body.rating);
    const comment = typeof req.body.comment === 'string' ? req.body.comment.trim() : '';
    const city = typeof req.body.city === 'string' ? req.body.city.trim() : undefined;

    if (!rating || rating < 1 || rating > 5) {
      res.status(400).json({ error: 'Please select a rating between 1 and 5.' });
      return;
    }
    if (comment.length < 5) {
      res.status(400).json({ error: 'Please write a short review (at least 5 characters).' });
      return;
    }

    const hasPurchased = store.orders.some(
      (o) =>
        o.userId === user.id &&
        o.items.some((item) => item.productId === product.id),
    );

    const newReview: ProductReview = {
      id: `rev-${Date.now()}`,
      userId: user.id,
      userName: user.name,
      city: city || user.defaultAddress?.city || 'India',
      rating,
      comment,
      date: new Date().toISOString().slice(0, 10),
      verified: hasPurchased,
    };

    product.reviews.unshift(newReview);
    product.reviewCount = product.reviews.length;
    product.rating = Number(
      (
        product.reviews.reduce((sum, r) => sum + r.rating, 0) /
        product.reviews.length
      ).toFixed(1),
    );

    saveStore(store);
    res.status(201).json({ product });
  });

  // Auth routes
  app.post('/api/auth/register', (req, res) => {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    const email =
      typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const phone = typeof req.body.phone === 'string' ? req.body.phone.trim() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';

    if (name.length < 2) {
      res.status(400).json({ error: 'Please enter your full name.' });
      return;
    }
    if (!email.includes('@')) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }

    const store = getStore();
    if (store.users.some((u) => u.email === email)) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const newUser = {
      id: `usr-${crypto.randomUUID().slice(0, 8)}`,
      name,
      email,
      phone: phone || '9000000000',
      role: 'customer' as UserRole,
      passwordHash: hashPassword(password),
      createdAt: new Date().toISOString(),
    };

    store.users.push(newUser);
    saveStore(store);

    const token = signToken(newUser.id, newUser.role);
    res.status(201).json({ token, user: sanitizeUser(newUser) });
  });

  app.post('/api/auth/login', (req, res) => {
    const email =
      typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';

    const store = getStore();
    const user = store.users.find((u) => u.email === email);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    const token = signToken(user.id, user.role);
    res.json({ token, user: sanitizeUser(user) });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
    const store = getStore();
    const user = store.users.find((u) => u.id === req.auth?.userId);
    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }
    res.json({ user: sanitizeUser(user) });
  });

  // Wishlist routes
  app.get('/api/wishlist', requireAuth, (req: AuthedRequest, res) => {
    const store = getStore();
    const ids = store.wishlists[req.auth!.userId] || [];
    res.json({ productIds: ids });
  });

  app.post('/api/wishlist/toggle', requireAuth, (req: AuthedRequest, res) => {
    const productId = typeof req.body.productId === 'string' ? req.body.productId : '';
    if (!productId) {
      res.status(400).json({ error: 'Product ID required.' });
      return;
    }
    const store = getStore();
    const current = new Set(store.wishlists[req.auth!.userId] || []);
    if (current.has(productId)) {
      current.delete(productId);
    } else {
      current.add(productId);
    }
    const updated = Array.from(current);
    store.wishlists[req.auth!.userId] = updated;
    saveStore(store);
    res.json({ productIds: updated });
  });

  // Coupons
  app.get('/api/coupons/public', (_req, res) => {
    const store = getStore();
    res.json({ coupons: store.coupons });
  });

  app.post('/api/coupons/validate', (req, res) => {
    const subtotal = Number(req.body.subtotal || 0);
    const code = typeof req.body.code === 'string' ? req.body.code : '';
    const result = calculateDiscount(subtotal, code);
    if (result.error) {
      res.status(400).json({ error: result.error });
      return;
    }
    res.json({
      valid: true,
      code: result.validCode,
      discount: result.discount,
    });
  });

  // Razorpay Test Mode order creation
  app.post('/api/payments/razorpay/create-order', async (req, res) => {
    const amountInRupees = Number(req.body.amount || 0);
    if (amountInRupees <= 0) {
      res.status(400).json({ error: 'Invalid payment amount.' });
      return;
    }
    const amountPaise = Math.round(amountInRupees * 100);
    const keyId = process.env.RAZORPAY_KEY_ID;
    const keySecret = process.env.RAZORPAY_KEY_SECRET;

    // If real Razorpay test credentials are configured in env, invoke Razorpay Orders API
    if (keyId && keySecret && keyId.startsWith('rzp_')) {
      try {
        const auth = Buffer.from(`${keyId}:${keySecret}`).toString('base64');
        const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Basic ${auth}`,
          },
          body: JSON.stringify({
            amount: amountPaise,
            currency: 'INR',
            receipt: `rcpt_${Date.now()}`,
          }),
        });
        if (rzpRes.ok) {
          const data = (await rzpRes.json()) as { id: string; amount: number; currency: string };
          res.json({
            mode: 'live_razorpay_sdk',
            keyId,
            razorpayOrderId: data.id,
            amountPaise: data.amount,
            currency: data.currency,
          });
          return;
        }
      } catch {
        // Fall back gracefully to built-in Razorpay Test Simulator
      }
    }

    const razorpayOrderId = `order_test_${crypto.randomBytes(6).toString('hex')}`;
    res.json({
      mode: 'razorpay_test_sandbox',
      keyId: 'rzp_test_vastra_atelier',
      razorpayOrderId,
      amountPaise,
      currency: 'INR',
    });
  });

  // Place Order (authenticated or guest-friendly if user signed in; requireAuth ensures order history tracking)
  app.post('/api/orders', (req: AuthedRequest, res) => {
    const store = getStore();
    const {
      items,
      shippingAddress,
      paymentMethod,
      couponCode,
      razorpayOrderId,
      razorpayPaymentId,
    } = req.body as {
      items: { productId: string; size: string; color: string; quantity: number }[];
      shippingAddress: ShippingAddress;
      paymentMethod: PaymentMethod;
      couponCode?: string;
      razorpayOrderId?: string;
      razorpayPaymentId?: string;
    };

    if (!Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'Your shopping bag is empty.' });
      return;
    }

    if (
      !shippingAddress ||
      !shippingAddress.fullName ||
      !shippingAddress.phone ||
      !shippingAddress.email ||
      !shippingAddress.street ||
      !shippingAddress.city ||
      !shippingAddress.state ||
      !/^\d{6}$/.test(shippingAddress.pinCode)
    ) {
      res.status(400).json({ error: 'Please complete a valid Indian shipping address and 6-digit PIN code.' });
      return;
    }

    const allowedMethods: PaymentMethod[] = ['UPI', 'CARD', 'NETBANKING', 'COD'];
    if (!allowedMethods.includes(paymentMethod)) {
      res.status(400).json({ error: 'Unsupported payment method.' });
      return;
    }

    // Validate inventory and compute authoritative prices server-side
    const verifiedItems: Order['items'] = [];
    for (const reqItem of items) {
      const product = store.products.find((p) => p.id === reqItem.productId);
      if (!product) {
        res.status(400).json({ error: 'One or more products in your bag are unavailable.' });
        return;
      }
      const qty = Math.max(1, Math.floor(Number(reqItem.quantity) || 1));
      if (product.stock < qty) {
        res.status(400).json({
          error: `Only ${product.stock} unit(s) remaining for ${product.name}.`,
        });
        return;
      }
      verifiedItems.push({
        productId: product.id,
        name: product.name,
        image: product.images[0] || '',
        size: (reqItem.size || product.sizes[0] || 'M') as Order['items'][number]['size'],
        color: reqItem.color || product.colors[0]?.name || 'Default',
        quantity: qty,
        price: product.price,
      });
    }

    // Deduct stock atomically
    for (const item of verifiedItems) {
      const product = store.products.find((p) => p.id === item.productId);
      if (product) {
        product.stock -= item.quantity;
      }
    }

    const subtotal = verifiedItems.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const { discount, validCode } = calculateDiscount(subtotal, couponCode);
    const afterDiscount = Math.max(0, subtotal - discount);
    const shippingFee = afterDiscount >= 2999 ? 0 : 149;
    const total = afterDiscount + shippingFee;

    const now = new Date().toISOString();
    const orderId = `ORD-VA-${Math.floor(10000 + Math.random() * 89999)}`;

    const userId = req.auth?.userId || `guest-${shippingAddress.email.toLowerCase()}`;
    if (req.auth?.userId) {
      const user = store.users.find((u) => u.id === req.auth!.userId);
      if (user) {
        user.defaultAddress = shippingAddress;
      }
    }

    const newOrder: Order = {
      id: orderId,
      userId,
      customerName: shippingAddress.fullName,
      customerEmail: shippingAddress.email,
      items: verifiedItems,
      shippingAddress,
      subtotal,
      discount,
      couponCode: validCode,
      shippingFee,
      total,
      paymentMethod,
      paymentStatus: paymentMethod === 'COD' ? 'Pending COD' : 'Paid',
      razorpayOrderId:
        paymentMethod === 'COD'
          ? undefined
          : razorpayOrderId || `order_test_${crypto.randomBytes(5).toString('hex')}`,
      razorpayPaymentId:
        paymentMethod === 'COD'
          ? undefined
          : razorpayPaymentId || `pay_test_${crypto.randomBytes(5).toString('hex')}`,
      status: paymentMethod === 'COD' ? 'Placed' : 'Confirmed',
      createdAt: now,
      updatedAt: now,
    };

    store.orders.unshift(newOrder);
    saveStore(store);

    res.status(201).json({ order: newOrder });
  });

  app.get('/api/orders/mine', requireAuth, (req: AuthedRequest, res) => {
    const store = getStore();
    const user = store.users.find((u) => u.id === req.auth?.userId);
    const orders = store.orders.filter(
      (o) =>
        o.userId === req.auth?.userId ||
        (user && o.customerEmail.toLowerCase() === user.email.toLowerCase()),
    );
    res.json({ orders });
  });

  // Newsletter subscription
  app.post('/api/newsletter', (req, res) => {
    const email =
      typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    if (!email || !email.includes('@')) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    const store = getStore();
    if (!store.newsletterSubscribers.some((s) => s.email === email)) {
      store.newsletterSubscribers.push({
        email,
        subscribedAt: new Date().toISOString(),
      });
      saveStore(store);
    }
    res.status(201).json({ message: 'Subscribed to Vastra Atelier journal & early access.' });
  });

  // ================= ADMIN ROUTES =================

  app.get('/api/admin/stats', requireAdmin, (_req, res) => {
    const store = getStore();
    const validOrders = store.orders.filter((o) => o.status !== 'Cancelled');
    const totalRevenue = validOrders.reduce((sum, o) => sum + o.total, 0);
    const totalOrders = store.orders.length;
    const averageOrderValue =
      validOrders.length > 0 ? Math.round(totalRevenue / validOrders.length) : 0;

    const categoryMap = new Map<string, { revenue: number; orders: number }>();
    for (const order of validOrders) {
      const seenCat = new Set<string>();
      for (const item of order.items) {
        const prod = store.products.find((p) => p.id === item.productId);
        const cat = prod?.category || 'Apparel';
        const existing = categoryMap.get(cat) || { revenue: 0, orders: 0 };
        existing.revenue += item.price * item.quantity;
        if (!seenCat.has(cat)) {
          existing.orders += 1;
          seenCat.add(cat);
        }
        categoryMap.set(cat, existing);
      }
    }

    const statuses: OrderStatus[] = [
      'Placed',
      'Confirmed',
      'Shipped',
      'Delivered',
      'Cancelled',
    ];
    const ordersByStatus = statuses.map((status) => ({
      status,
      count: store.orders.filter((o) => o.status === status).length,
    }));

    const stats: AdminStats = {
      totalRevenue,
      totalOrders,
      averageOrderValue,
      totalCustomers: store.users.filter((u) => u.role === 'customer').length,
      totalProducts: store.products.length,
      lowStockCount: store.products.filter((p) => p.stock <= 10).length,
      revenueByCategory: Array.from(categoryMap.entries()).map(([category, data]) => ({
        category,
        revenue: data.revenue,
        orders: data.orders,
      })),
      ordersByStatus,
    };

    res.json({ stats });
  });

  // Admin Image Upload (saves real image file into data/uploads)
  app.post('/api/admin/upload', requireAdmin, (req, res) => {
    const filename = typeof req.body.filename === 'string' ? req.body.filename : 'upload.jpg';
    const dataUrl = typeof req.body.dataUrl === 'string' ? req.body.dataUrl : '';

    const match = dataUrl.match(/^data:image\/(png|jpeg|jpg|webp);base64,(.+)$/i);
    if (!match) {
      res.status(400).json({ error: 'Please upload a valid PNG, JPG, or WebP image.' });
      return;
    }

    const ext = match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
    const base64Data = match[2];
    const buffer = Buffer.from(base64Data, 'base64');
    if (buffer.length > 8 * 1024 * 1024) {
      res.status(400).json({ error: 'Image size must be under 8MB.' });
      return;
    }

    ensureDataDirs();
    const safeStem = filename
      .replace(/\.[^/.]+$/, '')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 40);
    const outName = `${safeStem || 'product'}_${Date.now()}.${ext}`;
    fs.writeFileSync(path.join(UPLOADS_DIR, outName), buffer);

    res.status(201).json({ url: `/uploads/${outName}` });
  });

  app.post('/api/admin/products', requireAdmin, (req, res) => {
    const store = getStore();
    const body = req.body as Partial<Product>;
    if (!body.name || !body.category || !body.subcategory || !body.price) {
      res.status(400).json({ error: 'Name, category, subcategory, and price are required.' });
      return;
    }

    const slugBase = body.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    const id = `prod-${slugBase}-${Date.now().toString().slice(-4)}`;

    const newProduct: Product = {
      id,
      slug: `${slugBase}-${Date.now().toString().slice(-4)}`,
      sku: body.sku || `VA-${Date.now().toString().slice(-6)}`,
      name: body.name.trim(),
      category: body.category,
      subcategory: body.subcategory,
      description: body.description?.trim() || 'Handcrafted contemporary apparel.',
      fabricCare: body.fabricCare?.trim() || 'Natural breathable weave · Dry clean or gentle cold wash',
      price: Math.max(1, Number(body.price)),
      originalPrice: Math.max(
        Number(body.price),
        Number(body.originalPrice || body.price),
      ),
      sizes:
        Array.isArray(body.sizes) && body.sizes.length > 0
          ? body.sizes
          : ['S', 'M', 'L', 'XL'],
      colors:
        Array.isArray(body.colors) && body.colors.length > 0
          ? body.colors
          : [{ name: 'Obsidian', hex: '#111315' }],
      images:
        Array.isArray(body.images) && body.images.length > 0
          ? body.images
          : ['/src/assets/images/mens_linen_shirt_1795244909118.jpg'],
      stock: Math.max(0, Number(body.stock ?? 20)),
      rating: 5.0,
      reviewCount: 0,
      reviews: [],
      collections: Array.isArray(body.collections) ? body.collections : ['New Arrivals'],
      createdAt: new Date().toISOString(),
    };

    store.products.unshift(newProduct);
    saveStore(store);
    res.status(201).json({ product: newProduct });
  });

  app.put('/api/admin/products/:id', requireAdmin, (req, res) => {
    const store = getStore();
    const index = store.products.findIndex((p) => p.id === req.params.id);
    if (index === -1) {
      res.status(404).json({ error: 'Product not found.' });
      return;
    }

    const existing = store.products[index];
    const body = req.body as Partial<Product>;
    const updated: Product = {
      ...existing,
      name: body.name !== undefined ? body.name.trim() : existing.name,
      category: body.category !== undefined ? body.category : existing.category,
      subcategory: body.subcategory !== undefined ? body.subcategory : existing.subcategory,
      description:
        body.description !== undefined ? body.description.trim() : existing.description,
      fabricCare:
        body.fabricCare !== undefined ? body.fabricCare.trim() : existing.fabricCare,
      price: body.price !== undefined ? Math.max(1, Number(body.price)) : existing.price,
      originalPrice:
        body.originalPrice !== undefined
          ? Math.max(1, Number(body.originalPrice))
          : existing.originalPrice,
      stock: body.stock !== undefined ? Math.max(0, Number(body.stock)) : existing.stock,
      sizes: Array.isArray(body.sizes) && body.sizes.length > 0 ? body.sizes : existing.sizes,
      colors:
        Array.isArray(body.colors) && body.colors.length > 0 ? body.colors : existing.colors,
      images:
        Array.isArray(body.images) && body.images.length > 0 ? body.images : existing.images,
      collections:
        Array.isArray(body.collections) ? body.collections : existing.collections,
    };

    store.products[index] = updated;
    saveStore(store);
    res.json({ product: updated });
  });

  app.delete('/api/admin/products/:id', requireAdmin, (req, res) => {
    const store = getStore();
    const before = store.products.length;
    store.products = store.products.filter((p) => p.id !== req.params.id);
    if (store.products.length === before) {
      res.status(404).json({ error: 'Product not found.' });
      return;
    }
    saveStore(store);
    res.json({ deleted: true });
  });

  app.get('/api/admin/orders', requireAdmin, (_req, res) => {
    const store = getStore();
    res.json({ orders: store.orders });
  });

  app.patch('/api/admin/orders/:id/status', requireAdmin, (req, res) => {
    const store = getStore();
    const order = store.orders.find((o) => o.id === req.params.id);
    if (!order) {
      res.status(404).json({ error: 'Order not found.' });
      return;
    }
    const status = req.body.status as OrderStatus;
    const valid: OrderStatus[] = ['Placed', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
    if (!valid.includes(status)) {
      res.status(400).json({ error: 'Invalid order status.' });
      return;
    }
    order.status = status;
    order.updatedAt = new Date().toISOString();
    if (status === 'Delivered' && order.paymentMethod === 'COD') {
      order.paymentStatus = 'Paid';
    }
    saveStore(store);
    res.json({ order });
  });

  app.get('/api/admin/customers', requireAdmin, (_req, res) => {
    const store = getStore();
    const customers: CustomerSummary[] = store.users.map((u) => {
      const userOrders = store.orders.filter(
        (o) =>
          o.userId === u.id ||
          o.customerEmail.toLowerCase() === u.email.toLowerCase(),
      );
      return {
        id: u.id,
        name: u.name,
        email: u.email,
        phone: u.phone,
        role: u.role,
        createdAt: u.createdAt,
        orderCount: userOrders.length,
        totalSpent: userOrders
          .filter((o) => o.status !== 'Cancelled')
          .reduce((sum, o) => sum + o.total, 0),
      };
    });
    res.json({ customers });
  });

  // Vite dev middleware or production static assets
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Vastra Atelier server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start Vastra Atelier server:', err);
  process.exit(1);
});
